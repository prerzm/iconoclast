<?php

# include configuration file
include_once ("includes/inc.init.php");
include_once ("includes/lib.numbers.php");

# vars
$projectId = (int)aget('pId');
$vendor = aget('vendor');
$statusId = (int)aget('sId');
$dateFrom = get_pos_search_date_from(aget('dateFrom',10));
$dateTo = get_pos_search_date_to(aget('dateTo',10));

# queries
$results = get_contracts_vendors($projectId, $vendor, $statusId, $dateFrom, $dateTo);
$projects = get_projects_visible();
$status = get_contracts_status();

?>
<?php include("inc.header.main.php"); ?>

        <div class="container-fluid">
            
            <!-- row top -->
            <div class="row-fluid">
                <!-- sidebar -->
                <div class="span3" id="sidebar">
                    <div class="row-fluid">

                        <!-- search -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Buscar</div>
                            </div>
                            <div class="block-content collapse in">

                                <form id="form_search" method="get" action="contracts.admin.php">
                                    <fieldset>
                                        <div class="alert alert-error hide">
                                            <button class="close" data-dismiss="alert"></button>
                                            Hubo un problema. Favor de revisar la información.
                                        </div>
                                        <div class="alert alert-success hide">
                                            <button class="close" data-dismiss="alert"></button>
                                            La información es válida!
                                        </div>
                                        <?php if($projects) { ?>
                                        <div id="div_project" class="control-group">
                                            <label class="control-label">Proyecto</label>
                                            <div class="controls">
                                                <select class="span10 m-wrap" id="pId" name="pId" onchange="toggle_budget(this.value);">
                                                    <option value="0">Todos</option>
                                                    <?=form_select_options($projects, "proyectoId", "titulo", $projectId);?>
                                                </select>
                                            </div>
                                        </div>
                                        <?php } ?>
                                        <div class="control-group">
                                            <label class="control-label">Proveedor</label>
                                            <div class="controls">
                                                <input type="text" name="vendor" class="span10 m-wrap" value="<?=$vendor;?>" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Status</label>
                                            <div class="controls">
                                                <select class="span10 m-wrap" id="sId" name="sId">
                                                    <option value="0">Todos</option>
                                                    <?=form_select_options($status, "contratoStatusId", "contratoStatus", $statusId);?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Fecha de Firma</label>
                                            <div class="controls">
                                                <input type="text" name="dateFrom" class="span10 m-wrap datepicker" value="<?=$dateFrom;?>" /><br>
                                                <input type="text" name="dateTo" class="span10 m-wrap datepicker" value="<?=$dateTo;?>" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">&nbsp;</label>
                                            <div class="controls">
                                                <button type="submit" class="btn btn-primary">Buscar</button>
                                                <button type="reset" class="btn" onclick="window.location='pos.php';">Limpiar</button>
                                            </div>
                                        </div>
                                    </fieldset>
                                </form>
                                
                            </div>
                        </div>
                        <!-- ./search -->

                    </div>
                </div>
                <!-- ./sidebar -->
                
                <!-- content span -->
                <div class="span9" id="content">
                    <div class="row-fluid">
                        <!-- alerts -->
                        <?php display_alerts(); ?>
                        <!-- ./alerts -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <h2 style="color:#1b54a3;">Contratos Proveedores</h2>
                            </div>
                        </div>
                        <!-- breadcrumb -->
                        <div class="navbar">
                            <div class="navbar-inner">
                                <ul class="breadcrumb">
                                    <i class="icon-chevron-left hide-sidebar"><a href="#" title="Hide Sidebar" rel="tooltip">&nbsp;</a></i>
                                    <i class="icon-chevron-right show-sidebar" style="display:none;"><a href="#" title="Show Sidebar" rel="tooltip">&nbsp;</a></i>
                                    <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                                    <li class="active">Contratos Proveedores</li>
                                </ul>
                            </div>
                        </div>
                        <!-- ./breadcrumb -->
                    </div>
                    <!-- row -->
                    <div class="row-fluid">

                        <!-- form mass-authorize -->
                        <form method="post" action="mod/contracts.admin.php">
                        <input type="hidden" name="cmd" value="mass_del">

                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Resultados</div>
                            </div>
                            <div class="block-content collapse in">
                                <div class="span12">

                                    <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="results">
                                        <thead>
                                            <tr>
                                                <th>Proyecto</th>
                                                <th>Proveedor</th>
                                                <th>Contrato</th>
                                                <th>Anexo</th>
                                                <th>Carta NDA</th>
                                                <th>Firmado</th>
                                                <th>Status</th>
                                                <th>Revisión</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($results) { ?>
                                                <?php for($i=0; $i<count($results); $i++) { ?>
                                                    <tr>
                                                        <td><?=$results[$i]['titulo'];?></td>
                                                        <td><?=$results[$i]['razonSocial'];?></td>
                                                        <td>
                                                            <?php if( file_is_valid($results[$i]['contrato']) ) { ?>
                                                                <a href="file.download.php?f=<?=base64_encode($results[$i]['contrato']);?>&t=o" target="_blank" title="Descargar contrato"><img src="images/icon_pdf.png" /></a>
                                                            <?php } ?>
                                                        </td>
                                                        <td>
                                                            <?php if( file_is_valid($results[$i]['anexo']) ) { ?>
                                                                <a href="file.download.php?f=<?=base64_encode($results[$i]['anexo']);?>&t=o" target="_blank" title="Descargar anexo"><img src="images/icon_pdf.png" /></a>
                                                            <?php } ?>
                                                        </td>
                                                        <td>
                                                            <?php if( file_is_valid($results[$i]['carta']) ) { ?>
                                                                <a href="file.download.php?f=<?=base64_encode($results[$i]['carta']);?>&t=o" target="_blank" title="Descargar NDA"><img src="images/icon_pdf.png" /></a>
                                                            <?php } ?>
                                                        </td>
                                                        <td><?=$results[$i]['firmaFecha'];?></td>
                                                        <td><span class="label label-<?=$results[$i]['contratoStatus'];?>"><?=$results[$i]['contratoStatus'];?></span></td>
                                                        <td>
                                                            <?php if( file_is_valid($results[$i]['contrato']) || file_is_valid($results[$i]['carta']) ) { ?>
                                                                <a href="#myAlert<?=$results[$i]['id'];?>" data-toggle="modal" class="btn btn-warning"><i class="icon-repeat icon-white"></i> Rechazar</a>
                                                                <div id="myAlert<?=$results[$i]['id'];?>" class="modal hide">
                                                                    <div class="modal-header">
                                                                        <button data-dismiss="modal" class="close" type="button">&times;</button>
                                                                        <h3>Rechazar firma</h3>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <p>Está seguro que desea solicitar al proveedor que firme nuevamente sus documentos?</p>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <a class="btn btn-primary" href="mod/contracts.admin.php?cmd=del&id=<?=$results[$i]['id'];?>">Confirmar</a>
                                                                        <a data-dismiss="modal" class="btn" href="#">Cancelar</a>
                                                                    </div>
                                                                </div>
                                                            <?php } ?>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            <?php } ?>
                                        </tbody>
						            </table>
                                </div>
                            </div>
                        </div>
                        <!-- /block -->

                        </form>

                    </div>
                    <!-- ./row -->
                </div><!-- ./content span9 -->

            </div><!-- ./row top -->

            <hr>
            <footer>
                <p> <?=SITE_FOOTER_COPY;?></p>
            </footer>
        </div><!--/.fluid-container-->

        <!-- extra js -->
        <link rel="stylesheet" href="vendors/datepicker.css" media="screen">
        <script type="text/javascript" src="vendors/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
        <script type="text/javascript" src="vendors/datatables/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="assets/DT_bootstrap.js"></script>
        <script>

            $(document).ready(function() {

                $('#results').dataTable( {
                    "sDom": "<'row'<'span6'l><'span6'f>r>t<'row'<'span6'i><'span6'p>>",
                    "sPaginationType": "bootstrap",
                    "iDisplayLength": 50,
                    "aaSorting": [[5, 'desc']],
                } );

                $(".datepicker").datepicker();

            });

        </script>

<?php include("inc.footer.php"); ?>