<?php

# include configuration file
include_once ('../includes/inc.init.php');

# return
$return = "vendors.info.php";

# process
switch(aglobal('cmd', 20)) {

    case 'update':
	
        if($global_perms['EDIT']) {

            # vars
            $error = false;
            $vendorId = (int)session_get_data("userId");
            $record = get_vendor($vendorId);
            $vendor['email'] = apost('email', 150);

            # allow bank data change
            if(vendor_allow_edit_info($vendorId)) {
                $vendor['banco'] = apost('banco', 100);
                $vendor['cuenta'] = apost('cuenta', 20);
                $vendor['clabe'] = apost('clabe', 20);
            }
            $password = apost('pswd',20);

            # password
            if($password!="") {
                $vendor['password'] = sec_hash_password($password);
            }

            # files
            $acta = vendor_document_upload($vendorId, "acta");
            if($acta!==false) {
                $vendor['acta'] = $acta;
            }
            $constancia = vendor_document_upload($vendorId, "constancia");
            if($constancia!==false) {
                $vendor['constancia'] = $constancia;
            }
            $opinion = vendor_document_upload($vendorId, "opinionCumplimiento");
            if($opinion!==false) {
                $vendor['opinionCumplimiento'] = $opinion;
            }
            $estado = vendor_document_upload($vendorId, "estadoDeCuenta");
            if($estado!==false) {
                $vendor['estadoDeCuenta'] = $estado;
            }
            $identificacion = vendor_document_upload($vendorId, "identificacion");
            if($identificacion!==false) {
                $vendor['identificacion'] = $identificacion;
            }
            
            # update
            $updated = query_update(TABLE_VENDORS, $vendor, "proveedorId = $vendorId");

            if($updated>0) {
                $check = get_vendor($vendorId);
                if($check['constancia']!="" && $check['opinionCumplimiento']!="" && $check['estadoDeCuenta']!="") {
                    $return = "vendors.pos.php";
                }
                system_log($vendorId, TABLE_VENDORS, "Update", json_encode($vendor));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }
        
        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

    case 'delacta':

        if($global_perms['EDIT']) {

            # vars
            $vendorId = (int)session_get_data("userId");
            $vendor = get_vendor($vendorId);

            # queries
            $values['acta'] = "";
            file_delete($vendor['acta']);
            $updated = query_update(TABLE_VENDORS, $values, "proveedorId = $vendorId");
            
            if($updated>0) {
                system_log($vendorId, TABLE_VENDORS, "Update", json_encode($values));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

    case 'delcon':

        if($global_perms['EDIT']) {

            # vars
            $vendorId = (int)session_get_data("userId");
            $vendor = get_vendor($vendorId);

            # queries
            $values['constancia'] = "";
            file_delete($vendor['constancia']);
            $updated = query_update(TABLE_VENDORS, $values, "proveedorId = $vendorId");
            
            if($updated>0) {
                system_log($vendorId, TABLE_VENDORS, "Update", json_encode($values));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

    case 'delopn':

        if($global_perms['EDIT']) {

            # vars
            $vendorId = (int)session_get_data("userId");
            $vendor = get_vendor($vendorId);

            # queries
            $values['opinionCumplimiento'] = "";
            file_delete($vendor['opinionCumplimiento']);
            $updated = query_update(TABLE_VENDORS, $values, "proveedorId = $vendorId");
            
            if($updated>0) {
                system_log($vendorId, TABLE_VENDORS, "Update", json_encode($values));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

    case 'deledo':

        if($global_perms['EDIT']) {

            # vars
            $vendorId = (int)session_get_data("userId");
            $vendor = get_vendor($vendorId);

            # queries
            $values['estadoDeCuenta'] = "";
            file_delete($vendor['estadoDeCuenta']);
            $updated = query_update(TABLE_VENDORS, $values, "proveedorId = $vendorId");
            
            if($updated>0) {
                system_log($vendorId, TABLE_VENDORS, "Update", json_encode($values));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

    case 'delid':

        if($global_perms['EDIT']) {

            # vars
            $vendorId = (int)session_get_data("userId");
            $vendor = get_vendor($vendorId);

            # queries
            $values['identificacion'] = "";
            file_delete($vendor['identificacion']);
            $updated = query_update(TABLE_VENDORS, $values, "proveedorId = $vendorId");
            
            if($updated>0) {
                system_log($vendorId, TABLE_VENDORS, "Update", json_encode($values));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	default:

        # set error & error message on session
		set_alert("error", "Hubo un problema en la información, por favor intenta nuevamente.");
	
	break;
	
}

# redirect
redirect($return);

?>