<?php

# include configuration file
include_once ('../includes/inc.init.php');
require_once ("../includes/class.premailer.php");

# return
$return = "contracts.admin.php";

# process
switch(aglobal('cmd', 20)) {

	case 'update':
	
        if($global_perms['EDIT']) {

        
        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	case 'del':
    
        if($global_perms['DELETE']) {

            # vars
            $id = (int)aget('id');
            $record = get_contract_vendor($id);
            $project = get_project($record['proyectoId']);
            $vendor = get_vendor($record['proveedorId']);

            $file_contrato = $project['pathContratos'].$record['contrato'];
            $file_anexo = $project['pathContratos'].$record['anexo'];
            $file_carta = $project['pathContratos'].$record['carta'];
            
            # query
            $deleted = 1;
            if( file_is_valid($file_contrato) && file_delete($file_contrato) ) {
                $deleted++;
            }
            if( file_is_valid($file_anexo) && file_delete($file_anexo) ) {
                $deleted++;
            }
            if( file_is_valid($file_carta) && file_delete($file_carta) ) {
                $deleted++;
            }

            $updated = 0;
            if($deleted>0) {
                $updated = sql_query("UPDATE ".TABLE_CONTRACTS_VENDORS." SET firmaStatusId = ".CONTRACT_STATUS_PENDING.", firmaFecha = NULL WHERE id = $id");
            }
                
            if($updated>0) {
                $mail = new PREMailer();
                $mail->vendors_notify_contract_rejected($vendor['email'], $project['titulo']);
                system_log($id, TABLE_CONTRACTS_VENDORS, "Update", json_encode(array("firmaStatusId" => CONTRACT_STATUS_PENDING)));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	default:

        # set error & error message on session
		set_alert("error", "Hubo un problema en la información, por favor intenta nuevamente.");
	
	break;
	
}

# redirect
redirect($return);

?>