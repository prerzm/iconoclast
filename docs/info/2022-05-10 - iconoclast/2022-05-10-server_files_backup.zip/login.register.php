<?php

# includes
if($_SERVER['HTTP_HOST']=="localhost") {
    include_once ('includes/inc.config.php');
} else {
    include_once ('includes/inc.config.server.php');
}
include ('includes/lib.misc.php');
include ('includes/lib.sessions.php');
include ('includes/lib.vars.php');

# session
session_secure_start();

# vars

# form token
session_set_data( array("token" => sec_generate_random_token() ) );

?>
<!DOCTYPE html>
<html lang="es-MX">

	<head>
		<meta charset="utf-8">
		<title><?=SITE_NAME;?></title>
		<!-- Bootstrap -->
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
		<link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
		<link href="assets/styles.css" rel="stylesheet" media="screen">
		<link href="assets/DT_bootstrap.css" rel="stylesheet" media="screen">
		<link href="css/gabm.css" rel="stylesheet" media="screen">
		<!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<script src="vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
		<script src="vendors/jquery-1.9.1.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<script src="assets/scripts.js"></script>
	</head>

	<body id="login">

		<div class="container">

			<form name="form_register" id="form_register" class="form-signin" method="post" action="mod/login.php">
			<input type="hidden" name="cmd" value="register">
			<input type="hidden" name="token" value="<?php print session_get_data("token"); ?>">

				<h2 class="form-signin-heading">Registro</h2>
				<div class="alert alert-error hide">
					<button class="close" data-dismiss="alert"></button>
					Hubo un problema. Favor de revisar la información.
				</div>
				<div class="alert alert-success hide">
					<button class="close" data-dismiss="alert"></button>
					La información es válida!
				</div>

				<?php display_alerts(); ?>

				<div class="control-group">
					<div class="controls">
						<input type="text" name="rfc" data-required="1" class="input-block-level" placeholder="RFC" /><br>
					</div>
				</div>
				<div class="control-group">
					<div class="controls">
						<input type="text" name="razonSocial" data-required="1" class="input-block-level" placeholder="Razón Social" />
					</div>
				</div>
				<div class="control-group">
					<div class="controls">
						<input type="text" name="email" data-required="1" class="input-block-level" placeholder="Email" />
					</div>
				</div>
				<div class="control-group">
					<div class="controls">
						<input type="password" name="password" data-required="1" class="input-block-level" placeholder="Contraseña" />
					</div>
				</div>
				<div class="control-group">
					<div class="controls">
						<input type="password" name="passwordConfirm" data-required="1" class="input-block-level" placeholder="Confirmar Contraseña" />
					</div>
				</div>
				<div class="control-group">
					<div class="controls">
						<label for="aviso">
							<input type="checkbox" id="aviso" name="aviso" data-required="1" value="1" style="margin-top:0px;" />&nbsp;He leído y acepto el <a href="aviso.php">Aviso de Privacidad</a>
						</label>
					</div>
				</div>

				<p style="text-align:center;"><a href="login.php">Iniciar Sesión</a> | <a href="login.recover.php">Recuperar Contraseña</a></p><br>

				<button class="btn btn-large btn-primary" type="submit">Continuar</button>

			</form>

		</div> <!-- /container -->

		<!-- extra js -->
		<script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>

		<script>

			$(document).ready(function() {

				$('#form_register').validate({
					errorClass: 'help-inline',
					rules: {
						rfc: {
							minlength: 12,
							required: true
						},
						razonSocial: {
							required: true
						},
						email: {
							required: true,
							email: true
						},
						password: {
							minlength: 8,
							required: true
						},
						passwordConfirm: {
							minlength: 8,
							required: true
						}
					},
					focusCleanup: false,

					highlight: function(label) {
						$(label).closest('.control-group').removeClass('success').addClass('error');
					},
					success: function(label) {
						label
							.addClass('valid')
							.closest('.control-group').addClass('success');
					},
					errorPlacement: function(error, element) {
						error.appendTo( element.parents ('.controls') );
					}
				});

				$('.form').eq (0).find ('input').eq (0).focus ();

			});

		</script>

	</body>

</html>