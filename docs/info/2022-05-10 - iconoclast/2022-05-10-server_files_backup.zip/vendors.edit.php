<?php

# include configuration file
include_once ("includes/inc.init.php");

# vars & filters
$vendorId = (int)aget('id');

# queries
$record = get_vendor($vendorId);

?>
<?php include("inc.header.main.php"); ?>

        <div class="container-fluid">
            
            <!-- row top -->
            <div class="row-fluid">
                <!-- sidebar -->
                <div class="span3 hide" id="sidebar">
                    <div class="row-fluid">
                    </div>
                </div>
                <!-- ./sidebar -->
                
                <!-- content span12 -->
                <div class="span12" id="content">
                    <div class="row-fluid">
                        <!-- alerts -->
                        <?php display_alerts(); ?>
                        <!-- ./alerts -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <h2 style="color:#1b54a3;">Proveedores</h2>
                            </div>
                        </div>
                        <!-- breadcrumb -->
                        <div class="navbar">
                            <div class="navbar-inner">
                                <ul class="breadcrumb">
                                    <i class="icon-chevron-left hide-sidebar"><a href="#" title="Hide Sidebar" rel="tooltip">&nbsp;</a></i>
                                    <i class="icon-chevron-right show-sidebar" style="display:none;"><a href="#" title="Show Sidebar" rel="tooltip">&nbsp;</a></i>
                                    <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                                    <li><a href="vendors.php">Proveedores</a> <span class="divider">/</span></li>
                                    <li class="active">Editar</li>
                                </ul>
                            </div>
                        </div>
                        <!-- ./breadcrumb -->
                    </div>
                    <!-- row -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Editar</div>
                            </div>
                            <div class="block-content collapse in">

                                <!-- add-form-->
                                <form id="form_add" method="post" action="mod/vendors.php">
                                <input type="hidden" name="cmd" value="update">
                                <input type="hidden" name="id" value="<?=$vendorId;?>">
                                    <fieldset>
                                        <div class="alert alert-error hide">
                                            <button class="close" data-dismiss="alert"></button>
                                            Hubo un problema. Favor de revisar la información.
                                        </div>
                                        <div class="alert alert-success hide">
                                            <button class="close" data-dismiss="alert"></button>
                                            La información es válida!
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Nombre / Razón Social<span class="required">*</span></label>
                                            <div class="controls">
                                                <input type="text" name="razonSocial" data-required="1" class="span10 m-wrap" value="<?=$record['razonSocial'];?>" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">RFC / NIF</label>
                                            <div class="controls">
                                                <input type="text" name="rfc" data-required="1" class="span10 m-wrap" value="<?=$record['rfc'];?>" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">email</label>
                                            <div class="controls">
                                                <input type="text" name="email" class="span10 m-wrap" value="<?=$record['email'];?>" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Proveedor extranjero</label>
                                            <div class="controls">
                                                <label><input type="radio" name="extranjero" value="0" onclick="update_extranjero(this.value);" <?=($record['extranjero']==0) ? 'checked' : '';?>> No</label>
                                                <label><input type="radio" name="extranjero" value="1" onclick="update_extranjero(this.value);" <?=($record['extranjero']==1) ? 'checked' : '';?>> Sí</label>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Tipo de Contrato y NDA</label>
                                            <div class="controls">
                                                <select class="span10 m-wrap" name="agencia">
                                                    <option value="0" <?=($record['agencia']==0) ? 'selected' : '';?>>Normal</option>
                                                    <option value="1" <?=($record['agencia']==1) ? 'selected' : '';?>>Agencias/Talentos</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Banco</label>
                                            <div class="controls">
                                                <input type="text" name="banco" class="span10 m-wrap" value="<?=$record['banco'];?>" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Cuenta</label>
                                            <div class="controls">
                                                <input type="text" name="cuenta" class="span10 m-wrap" value="<?=$record['cuenta'];?>" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">CLABE</label>
                                            <div class="controls">
                                                <input type="text" name="clabe" class="span10 m-wrap" value="<?=$record['clabe'];?>" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Contraseña (Solo si desea cambiar)</label>
                                            <div class="controls">
                                                <input type="text" name="pswd" class="span10 m-wrap" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">&nbsp;</label>
                                            <div class="controls">
                                                <button type="reset" class="btn btn-inverse" onclick="window.location='vendors.view.php?id=<?=$vendorId;?>';"><i class="icon-arrow-left icon-white"></i> Cancelar</button>
                                                <button type="submit" class="btn btn-primary"><i class="icon-pencil icon-white"></i> Guardar</button>
                                                <?php if($global_perms['DELETE']) { ?>
                                                    <a href="#myAlert" data-toggle="modal" class="btn btn-danger"><i class="icon-remove icon-white"></i> Eliminar</a>
                                                <?php } ?>
                                                <div id="myAlert" class="modal hide">
                                                    <div class="modal-header">
                                                        <button data-dismiss="modal" class="close" type="button">&times;</button>
                                                        <h3>Eliminar</h3>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>Está seguro que desea eliminar este registro?</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <a class="btn btn-primary" href="mod/vendors.php?cmd=del&id=<?=$vendorId;?>">Confirmar</a>
                                                        <a data-dismiss="modal" class="btn" href="#">Cancelar</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </fieldset>
                                </form>
                                <!-- ./add-form -->
                                
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    <!-- ./row -->
                </div><!-- ./content span9 -->

            </div><!-- ./row top -->

            <hr>
            <footer>
                <p> <?=SITE_FOOTER_COPY;?></p>
            </footer>
        </div><!--/.fluid-container-->

        <!-- extra js -->
        <script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
        <script>

            $(document).ready(function() {

                $('#form_add').validate({
                    errorClass: 'help-inline',
                    rules: {
                        permisoKey: {
                            minlength: 3,
                            required: true
                        },
                        name: {
                            minlength: 4,
                            required: true
                        },
                        archivos: {
                            minlength: 6,
                            required: true
                        }
                    },
                    focusCleanup: false,

                    highlight: function(label) {
                        $(label).closest('.control-group').removeClass('success').addClass('error');
                    },
                    success: function(label) {
                        label
                            .addClass('valid')
                            .closest('.control-group').addClass('success');
                    },
                    errorPlacement: function(error, element) {
                        error.appendTo( element.parents ('.controls') );
                    }
                });

                $('.form').eq (0).find ('input').eq (0).focus ();

            });

            // extranjero - show/hide fields
            function update_extranjero(val) {
                if(val==0) {
                } else {
                }
            }

        </script>

<?php include("inc.footer.php"); ?>