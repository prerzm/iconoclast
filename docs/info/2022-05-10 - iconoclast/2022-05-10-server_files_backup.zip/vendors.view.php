<?php

# include configuration file
include_once ("includes/inc.init.php");

# vars & filters
$vendorId = (int)aget('id');

# queries
$record = get_vendor($vendorId);
$contracts = get_contracts_vendor($vendorId);

?>
<?php include("inc.header.main.php"); ?>

        <div class="container-fluid">
            
            <!-- row top -->
            <div class="row-fluid">

                <!-- content span -->
                <div class="span12" id="content">
                    <div class="row-fluid">
                        <!-- alerts -->
                        <?php display_alerts(); ?>
                        <!-- ./alerts -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <h2 style="color:#1b54a3;">Proveedor - <?=$record['razonSocial'];?></h2>
                            </div>
                        </div>
                        <!-- breadcrumb -->
                        <div class="navbar">
                            <div class="navbar-inner">
                                <ul class="breadcrumb">
                                    <i class="icon-chevron-left hide-sidebar"><a href="#" title="Hide Sidebar" rel="tooltip">&nbsp;</a></i>
                                    <i class="icon-chevron-right show-sidebar" style="display:none;"><a href="#" title="Show Sidebar" rel="tooltip">&nbsp;</a></i>
                                    <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                                    <li><a href="vendors.php">Proveedores</a> <span class="divider">/</span></li>
                                    <li class="active">Editar</li>
                                </ul>
                            </div>
                        </div>
                        <!-- ./breadcrumb -->
                    </div>
                    <!-- row -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Proveedor</div>
                            </div>
                            <div class="block-content collapse in">

                                <table class="table">
                                    <tr>
                                        <th style="width:30%;">Datos</th>
                                        <td>
                                            <strong>Razón Social</strong>: <?=$record['razonSocial'];?><br>
                                            <strong>RFC</strong>: <?=$record['rfc'];?><br>
                                            <strong>Email</strong>: <?=$record['email'];?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Datos Bancarios</th>
                                        <td>
                                            <strong>Banco</strong>: <?=$record['banco'];?><br>
                                            <strong>Cuenta</strong>: <?=$record['cuenta'];?><br>
                                            <strong>CLABE</strong>: <?=$record['clabe'];?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th style="border-top:none;">Documentos</th>
                                        <td style="border-top:none;"><?=($record['extranjero']==1) ? 'Proveedor extranjero' : '&nbsp;';?></td>
                                    </tr>
                                    <?php if($record['extranjero']==0) { ?>
                                        <?php if(get_vendor_type($record['rfc'])=="pm") { ?>
                                            <tr>
                                                <td>Acta Constitutiva</td>
                                                <td>
                                                    <?php if( file_is_valid($record['acta']) ) { ?>
                                                        <a href="file.download.php?f=<?=base64_encode($record['acta']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                    <?php } else { ?>
                                                        <span class="label label-warning">Pendiente</span>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                        <tr>
                                            <td>Constancia de Situación Fiscal</td>
                                            <td>
                                                <?php if( file_is_valid($record['constancia']) ) { ?>
                                                    <a href="file.download.php?f=<?=base64_encode($record['constancia']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                <?php } else { ?>
                                                    <span class="label label-warning">Pendiente</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Opinión del Cumplimiento (D32)</td>
                                            <td>
                                                <?php if( file_is_valid($record['opinionCumplimiento']) ) { ?>
                                                    <a href="file.download.php?f=<?=base64_encode($record['opinionCumplimiento']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                <?php } else { ?>
                                                    <span class="label label-warning">Pendiente</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Carátula Estado de Cuenta</td>
                                            <td>
                                                <?php if( file_is_valid($record['estadoDeCuenta']) ) { ?>
                                                    <a href="file.download.php?f=<?=base64_encode($record['estadoDeCuenta']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                <?php } else { ?>
                                                    <span class="label label-warning">Pendiente</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Identificación Oficial</td>
                                            <td>
                                                <?php if( file_is_valid($record['identificacion']) ) { ?>
                                                    <a href="file.download.php?f=<?=base64_encode($record['identificacion']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                <?php } else { ?>
                                                    <span class="label label-warning">Pendiente</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <th>&nbsp;</th>
                                    </tr>
                                    <tr>
                                        <th style="border-top:none;">Contratos</th>
                                        <td style="border-top:none;"><?=($record['agencia']==0) ? 'Normal' : 'Agencia/Talento';?></td>
                                    </tr>
                                    <?php if($contracts) { ?>
                                        <tr>
                                            <td colspan="2">
                                                <table>
                                                    <tr>
                                                        <th style="border-top:none;">Proyecto</th>
                                                        <th style="border-top:none;">Contrato</th>
                                                        <th style="border-top:none;">Anexo</th>
                                                        <th style="border-top:none;">Carta NDA</th>
                                                        <th style="border-top:none;">Estatus</th>
                                                    </tr>
                                                    <?php for($i=0; $i<count($contracts); $i++) { ?>
                                                        <tr>
                                                            <td><?=$contracts[$i]['titulo'];?></td>
                                                            <td>
                                                                <?php if( file_is_valid($contracts[$i]['contrato']) ) { ?>
                                                                    <a href="file.download.php?f=<?=base64_encode($contracts[$i]['contrato']);?>&t=o" title="Descargar contrato"><img src="images/icon_pdf.png" /></a>
                                                                <?php } ?>
                                                            </td>
                                                            <td>
                                                                <?php if( file_is_valid($contracts[$i]['anexo']) ) { ?>
                                                                    <a href="file.download.php?f=<?=base64_encode($contracts[$i]['anexo']);?>&t=o" title="Descargar anexo"><img src="images/icon_pdf.png" /></a>
                                                                <?php } ?>
                                                            </td>
                                                            <td>
                                                                <?php if( file_is_valid($contracts[$i]['carta']) ) { ?>
                                                                    <a href="file.download.php?f=<?=base64_encode($contracts[$i]['carta']);?>&t=o" title="Descargar NDA"><img src="images/icon_pdf.png" /></a>
                                                                <?php } ?>
                                                            </td>
                                                            <td><span class="label label-<?=$contracts[$i]['contratoStatus'];?>"><?=$contracts[$i]['contratoStatus'];?></span></td>
                                                        </tr>
                                                    <?php } ?>
                                                </table>
                                            </td>
                                        </tr>
                                    <?php } else { ?>
                                        <tr>
                                            <th>Este proveedor no tiene contratos</th>
                                            <td>&nbsp;</td>
                                        </tr>
                                    <?php } ?>
                                </table>

                                <div class="control-group">
                                    <label class="control-label">&nbsp;</label>
                                    <div class="controls">
                                        <a href="vendors.php" class="btn btn-inverse"><i class="icon-arrow-left icon-white"></i> Regresar</a>
                                        <?php if($global_perms['EDIT']) { ?>
                                            <a href="vendors.edit.php?id=<?=$vendorId;?>" class="btn btn-primary"><i class="icon-edit icon-white"></i> Editar</a>
                                        <?php } ?>
                                        <?php if($global_perms['DELETE']) { ?>
                                            <a href="#myAlert" data-toggle="modal" class="btn btn-danger"><i class="icon-remove icon-white"></i> Eliminar</a>
                                        <?php } ?>
                                        <div id="myAlert" class="modal hide">
                                            <div class="modal-header">
                                                <button data-dismiss="modal" class="close" type="button">&times;</button>
                                                <h3>Eliminar</h3>
                                            </div>
                                            <div class="modal-body">
                                                <p>Está seguro que desea eliminar este registro?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <a class="btn btn-primary" href="mod/vendors.php?cmd=del&id=<?=$vendorId;?>">Confirmar</a>
                                                <a data-dismiss="modal" class="btn" href="#">Cancelar</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    <!-- ./row -->
                </div><!-- ./content span9 -->

            </div><!-- ./row top -->

            <hr>
            <footer>
                <p> <?=SITE_FOOTER_COPY;?></p>
            </footer>
        </div><!--/.fluid-container-->

<?php include("inc.footer.php"); ?>