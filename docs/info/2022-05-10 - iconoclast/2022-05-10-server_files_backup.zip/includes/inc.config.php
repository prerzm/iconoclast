<?php

/** RZM PHP Framework **/

# Locale settings
#setlocale(LC_ALL, 'es_MX');
date_default_timezone_set('America/Mexico_City');

# Set the error reporting level
define("ENVIRONMENT", "DEVELOPMENT");
error_reporting(E_ALL);	// DEVELOPMENT

# Site settings
define("SITE_NAME", "PRIMO");
define("SITE_URL", "http://localhost/primo/");
define("SITE_FOOTER_COPY", "");

# Database login details
define("HOST", "localhost");
define("DATABASE", "servicio_primo");
define("USER", "root");
define("PASSWORD", '');

# Secure settings
define("SEC_SESSION_ID", "sess_primo");
define("SEC_SALT", "PRIMO$301020");
define("SECURE_HTTP", "0");
define("HTTP_ONLY", "1");

# Path settings
define("PATH_ROOT", "C:/Users/ramir/Box/PRE/Sites/primo/");
define("PATH_PROJECTS", PATH_ROOT . "files/projects/");
define("PATH_EXPENSES", PATH_ROOT . "files/expenses/");
define("PATH_VENDORS", PATH_ROOT . "files/vendors/");
define("PATH_DBUPDATE", PATH_ROOT . "files/db/");
define("PATH_MAILS", PATH_ROOT . "mails/");

# Company settings
define("COMPANY_ID", "1");

# Mail settings
define("MAIL_FROM", "plataforma@serviciosabp.com");
define("MAIL_FROM_NAME", "Plataforma ABP");
define("MAIL_REPLY_TO", "rzendejas@preisc.com");
define("MAIL_HOST", "secure.emailsrvr.com");
define("MAIL_PORT", "465");
define("MAIL_USER", "plataforma@serviciosabp.com");
define("MAIL_PSWD", "duyanHVF4HBxd2q");

# Other settings
define("PAYMENT_STATUS_PENDING", "1");
define("PAYMENT_STATUS_AUTHORIZED", "2");
define("PAYMENT_STATUS_PAYED", "3");
define("PAYMENT_STATUS_CANCELLED", "4");
define("CONTRACT_STATUS_PENDING", "1");
define("CONTRACT_STATUS_SIGNED", "2");
define("CONTRACT_STATUS_APROVED", "3");
define("CONTRACT_PROVEEDORES_PM", "1");
define("CONTRACT_SERVICIOS_PF", "2");
define("CARTA_NDA", "3");
define("ROLE_VENDOR", "9");
define("PRIMO_SIGNATURE", PATH_ROOT . "files/signatures/firma_primo.png");

?>