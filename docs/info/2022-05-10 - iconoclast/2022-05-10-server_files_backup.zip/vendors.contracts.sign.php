<?php

# include configuration file
include_once ("includes/class.contracts.php");
include_once ("includes/inc.init.php");
include_once ("includes/lib.dates.php");
include_once ("includes/lib.numbers.php");

# vars & filters
$contract = session_get_data("contract");

if(!is_object($contract)) {
    die("error");
}

$record = get_contract_vendor($contract->id);
$project = get_project($record['proyectoId']);
$vendor = get_vendor($record['proveedorId']);

$contract->set_body_as_text();
$contract->replace_info($project, $vendor);
$contract_html = $contract->get_html();

?>
<?php include("inc.header.main.php"); ?>

        <div class="container-fluid">
            
            <!-- row top -->
            <div class="row-fluid">

                <!-- content span -->
                <div class="span12" id="content">
                    <div class="row-fluid">
                        <!-- alerts -->
                        <?php display_alerts(); ?>
                        <!-- ./alerts -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <h2 style="color:#1b54a3;">Firma</h2>
                            </div>
                        </div>
                        <!-- breadcrumb -->
                        <div class="navbar">
                            <div class="navbar-inner">
                                <ul class="breadcrumb">
                                    <i class="icon-chevron-left hide-sidebar"><a href="#" title="Hide Sidebar" rel="tooltip">&nbsp;</a></i>
                                    <i class="icon-chevron-right show-sidebar" style="display:none;"><a href="#" title="Show Sidebar" rel="tooltip">&nbsp;</a></i>
                                    <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                                    <li><a href="vendors.contracts.php">Contratos</a> <span class="divider">/</span></li>
                                    <li class="active">Firma</li>
                                </ul>
                            </div>
                        </div>
                        <!-- ./breadcrumb -->
                    </div>

                    <!-- row -->
                    <div class="row-fluid">
                        <div class="span12">
                            <!-- block -->
                            <div class="block">
                                <div class="navbar navbar-inner block-header">
                                    <div class="muted pull-left">Firmar</div>
                                </div>
                                <div class="block-content collapse in">

                                    <form id="form-sign" method="post" action="mod/vendors.contracts.php" enctype="multipart/form-data">
                                    <input type="hidden" name="signature" id="formimage" value="">
                                    <input type="hidden" name="cmd" value="sign">

                                        <div>
                                            <?=$contract_html;?>
                                        </div>

                                        <div class="alert alert-error">
                                            <h4>Es necesario que su firma sea lo más parecido posible a la identificación que ha subido anteriormente</h4>
                                        </div>

                                        <div class="control-group">
                                            <label class="control-label">Firmar en el espacio en blanco</label>
                                            <div id="canvas">
                                                <canvas id="newSignature" style="position: relative; margin: 0; padding: 0; border: 1px solid #c4caac;"></canvas><br>
                                                <button type="button" class="btn" onclick="signatureClear()">Borrar firma</button>
                                            </div>
                                        </div>

                                        <div class="control-group">
                                            <label class="control-label">&nbsp;</label>
                                            <div class="controls">
                                                <button type="button" onclick="signatureSave()" class="btn btn-primary"><i class="icon-upload icon-white"></i> Guardar firma y generar Contrato</button>
                                                <a href="#" class="btn btn-inverse" onclick="history.back();"><i class="icon-arrow-left icon-white"></i> Regresar</a>
                                            </div>
                                        </div>

                                    </form>
                                    
                                </div>
                            </div>
                            <!-- /block -->
                        </div>
                        <!-- ./span -->

                    </div>
                    <!-- ./row -->

                </div><!-- ./content span9 -->

            </div><!-- ./row top -->

            <hr>
            <footer>
                <p> <?=SITE_FOOTER_COPY;?></p>
            </footer>
        </div><!--/.fluid-container-->

        <!-- extra js -->
        <script type="text/javascript" src="vendors/signsend/signaturesave.js"></script>
        <script>signatureCapture();</script>

<?php include("inc.footer.php"); ?>