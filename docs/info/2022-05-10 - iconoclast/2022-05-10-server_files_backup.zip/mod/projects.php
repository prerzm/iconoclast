<?php

# include configuration file
include_once ('../includes/inc.init.php');

# return
$return = "projects.php";

# process
switch(aglobal('cmd', 20)) {

    case 'add':
        
        if($global_perms['ADD']) {

            # vars
            $error = false;
            $project['uniqId'] = uniqid();
            $project['clave'] = apost('clave', 10);
            $project['titulo'] = apost('titulo', 150);
            $project['cliente'] = apost('cliente', 150);
            $project['director'] = apost('director', 150);
            $project['diaFilmacion'] = apost('diaFilmacion', 10);
            $project['productor'] = apost('productor', 150);
            $project['productorLinea'] = apost('productorLinea', 150);

            # create project
            $projectId = query_insert(TABLE_PROJECTS, $project);

            if($projectId>0) {

                # folders
                project_create_paths($project['uniqId']);

                # log
                system_log($projectId, TABLE_PROJECTS, "Add", json_encode($project));

                set_alert("success", "La información ha sido actualizada");

            } else {

                set_alert("error", "Hubo un problema, favor de intentar nuevamente");

            }
        
        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	case 'update':
	
        if($global_perms['EDIT']) {

            # vars
            $error = false;
            $updated = 0;
            $projectId = (int)apost('id');
            $project['clave'] = apost('clave', 10);
            $project['titulo'] = apost('titulo', 150);
            $project['cliente'] = apost('cliente', 150);
            $project['diaFilmacion'] = apost('diaFilmacion', 10);
            $project['director'] = apost('director', 150);
            $project['productor'] = apost('productor', 150);
            $project['productorLinea'] = apost('productorLinea', 150);

            # update
            $updated += query_update(TABLE_PROJECTS, $project, "proyectoId = $projectId");
                
            if($updated>0) {

                system_log($projectId, TABLE_PROJECTS, "Update", json_encode($project));
                set_alert("success", "La información ha sido actualizada.");

            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }
        
        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	case 'del':
    
        if($global_perms['DELETE']) {

            # vars
            $projectId = (int)aget('id');
            $project['deleted'] = 1;

            # query
            $updated = query_update(TABLE_PROJECTS, $project, "proyectoId = $projectId");
                
            if($updated>0) {
                system_log($projectId, TABLE_PROJECTS, "Delete", json_encode($project));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	case 'on':
    
        if($global_perms['EDIT']) {

            # vars
            $projectId = (int)aget('id');
            $project['activo'] = 1;

            # query
            $updated = query_update(TABLE_PROJECTS, $project, "proyectoId = $projectId");
                
            if($updated>0) {
                system_log($projectId, TABLE_PROJECTS, "Show", json_encode($project));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	case 'off':
    
        if($global_perms['EDIT']) {

            # vars
            $projectId = (int)aget('id');
            $project['activo'] = 0;

            # query
            $updated = query_update(TABLE_PROJECTS, $project, "proyectoId = $projectId");
                
            if($updated>0) {
                system_log($projectId, TABLE_PROJECTS, "Hide", json_encode($project));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

    default:

        # set error & error message on session
		set_alert("error", "Hubo un problema en la información, por favor intenta nuevamente.");
	
	break;
	
}

# redirect
redirect($return);

?>