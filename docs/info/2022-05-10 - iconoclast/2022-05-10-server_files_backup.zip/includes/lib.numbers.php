<?php

/** RZM PHP Framework **/

// Function for return a float number from a string
function number_float($number, $decimals=2) {

	$number = (float)str_replace( array("$", ",", " "), "", $number);

	return number_format($number, $decimals, ".", "");
	
}

// Function to format number as currency
function number_currency($amount, $symbol="$", $code="") {

	# strip amount
	$amount	= str_replace(array(",", "$", " "), "", $amount);

	if($code=="") {
		$code = "";
	} else {
		$code = " ".$code;
	}

	return $symbol." ".number_format($amount, 2, ".", ",").$code;
	
}


// Function to format number as thousands.decimals
function number_thousands_decimals($amount, $decimals=2) {

	# strip amount
	$amount	= str_replace(array(",", "$", " "), "", $amount);

	return number_format($amount, $decimals, ".", ",");
	
}


// Function to format number as thousands
function number_thousands($amount) {

	# strip amount
	$amount	= str_replace(array(",", "$", " "), "", $amount);
	$amount = $amount * 1;

	return number_format($amount, 0, "", ",");
	
}


?>