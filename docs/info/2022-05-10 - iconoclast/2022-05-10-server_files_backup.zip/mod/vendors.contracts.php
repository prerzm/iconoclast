<?php

# include configuration file
include_once ("../includes/class.contracts.php");
include_once ('../includes/inc.init.php');

# return
$return = "vendors.contracts.php";

# process
switch(aglobal('cmd', 25)) {

    case 'fill':

        # vars
        $contract = session_get_data("contract");

        $record = get_contract_vendor($contract->id);
        $project = get_project($record['proyectoId']);
        $vendor = get_vendor($record['proveedorId']);

        $contract->fill($_POST);
        $contract->upload_attach($_FILES, $vendor['rfc'], $project['pathContratos']);

        session_set_data(array("contract_id" => $id, "contract" => $contract));

        # redirect
        $return = "vendors.contracts.sign.php";

    break;

	case 'sign':

        # includes
        include_once ("../includes/lib.dates.php");
        require('../includes/class.primopdf.php');
        
        # vars
        $contract = session_get_data("contract");
        $record = get_contract_vendor($contract->id);
        $project = get_project($record['proyectoId']);
        $vendor = get_vendor($record['proveedorId']);

        # save signature image
        $signature_image = str_replace('data:image/png;base64,', '', $_POST['signature']);
        $signature_image = base64_decode($signature_image);
        $signature_filename = get_contract_signature_filename($vendor['rfc']);
        $signature_saved = save_contract_signature($project['pathFirmas'], $signature_filename, $signature_image);

        # create pdf
        $pdf = $contract->create_pdf($project, $vendor, $signature_filename);
        
        if($pdf) {
            $new_record = get_contract_vendor($contract->id);
            if($new_record['contrato']!="" && $new_record['carta']!="") {
                query_update(TABLE_CONTRACTS_VENDORS, array("firmaStatusId" => CONTRACT_STATUS_SIGNED, "firmaFecha" => date("Y-m-d")), "id = ".$contract->id);
            }
            session_unset_data("contract");
            set_alert("success", "El documento ha sido firmado.");
        } else {
            set_alert("error", "Hubo un problema al firmar el documento.");
        }

    break;

    case 'download':

        # vars
        $id = (int)aget('id');

        # records
        $record = get_contract_vendor($id);
        $project = get_project($record['proyectoId']);

        $file_contrato = $project['pathContratos'].$record['contrato'];
        $file_anexo = $project['pathContratos'].$record['anexo'];

        # process
        if(file_is_valid($file_contrato)) {

            if(file_is_valid($file_anexo)) {

                require("../includes/class.concatpdf.php");
                
                $pdf = new ConcatPdf();
                $pdf->setFiles(array($file_contrato, $file_anexo));
                $pdf->concat();
                
                $pdf->Output();

            } else {

                file_download(base64_encode($file_contrato), "pdf");
                die();

            }

        }

    break;

	case 'updload':
	
        if($global_perms['EDIT']) {

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	default:

        # set error & error message on session
		set_alert("error", "Hubo un problema en la información, por favor intenta nuevamente.");
	
	break;
	
}

# redirect
redirect($return);

?>