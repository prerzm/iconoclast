<?php

# include configuration file
include_once ("includes/inc.init.php");

# vars & filters
$vendorId = (int)session_get_data("userId");

# queries
$record = get_vendor($vendorId);
$allow_update_info = vendor_allow_edit_info($vendorId);

?>
<?php include("inc.header.main.php"); ?>

        <div class="container-fluid">
            
            <!-- row top -->
            <div class="row-fluid">
                <!-- sidebar -->
                <div class="span3 hide" id="sidebar">
                    <div class="row-fluid">
                    </div>
                </div>
                <!-- ./sidebar -->
                
                <!-- content span12 -->
                <div class="span12" id="content">
                    <div class="row-fluid">
                        <!-- alerts -->
                        <?php display_alerts(); ?>
                        <!-- ./alerts -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <h2 style="color:#1b54a3;">Información</h2>
                            </div>
                        </div>
                        <!-- breadcrumb -->
                        <div class="navbar">
                            <div class="navbar-inner">
                                <ul class="breadcrumb">
                                    <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                                    <li class="active">Información</li>
                                </ul>
                            </div>
                        </div>
                        <!-- ./breadcrumb -->
                    </div>
                    <!-- row -->
                    <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
                            <div class="navbar navbar-inner block-header">
                                <div class="muted pull-left">Editar</div>
                            </div>
                            <div class="block-content collapse in">

                                <!-- add-form-->
                                <form id="form_add" method="post" action="mod/vendors.info.php" enctype="multipart/form-data">
                                <input type="hidden" name="cmd" value="update">
                                
                                    <fieldset>
                                        <div class="alert alert-error hide">
                                            <button class="close" data-dismiss="alert"></button>
                                            Hubo un problema. Favor de revisar la información.
                                        </div>
                                        <div class="alert alert-success hide">
                                            <button class="close" data-dismiss="alert"></button>
                                            La información es válida!
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Nombre / Razón Social</label>
                                            <div class="controls">
                                                <strong><?=$record['razonSocial'];?></strong>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">RFC / NIF</label>
                                            <div class="controls">
                                                <strong><?=$record['rfc'];?></strong>
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">email</label>
                                            <div class="controls">
                                                <input type="text" name="email" class="span10 m-wrap" value="<?=$record['email'];?>" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Banco</label>
                                            <div class="controls">
                                                <input type="text" name="banco" class="span10 m-wrap" value="<?=$record['banco'];?>" <?=($allow_update_info) ? '' : 'disabled';?> />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">Cuenta</label>
                                            <div class="controls">
                                                <input type="text" name="cuenta" class="span10 m-wrap" value="<?=$record['cuenta'];?>" <?=($allow_update_info) ? '' : 'disabled';?> />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">CLABE</label>
                                            <div class="controls">
                                                <input type="text" name="clabe" class="span10 m-wrap" value="<?=$record['clabe'];?>" <?=($allow_update_info) ? '' : 'disabled';?> />
                                            </div>
                                        </div>
                                        <?php if($record['extranjero']==0) { ?>
                                            <?php if(get_vendor_type($record['rfc'])=="pm") { ?>
                                            <div class="control-group">
                                                <label class="control-label" <?=((bool)VENDOR_REQ_ID==true && !file_is_valid($record['acta'])) ? 'style="color:#da4f49;";' : '';?>>Acta Constitutiva (Formato PDF)</label>
                                                <div class="controls">
                                                    <?php if( file_is_valid($record['acta']) ) { ?>
                                                        <a href="file.download.php?f=<?=base64_encode($record['acta']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                    <?php } else { ?>
                                                        <input type="file" name="acta" class="span10 m-wrap"/>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <?php } ?>
                                            <div class="control-group">
                                                <label class="control-label" <?=((bool)VENDOR_REQ_CSF==true && !file_is_valid($record['constancia'])) ? 'style="color:#da4f49;";' : '';?>>Constancia de Situación Fiscal</label>
                                                <div class="controls">
                                                    <?php if( file_is_valid($record['constancia']) ) { ?>
                                                        <a href="file.download.php?f=<?=base64_encode($record['constancia']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                    <?php } else { ?>
                                                        <input type="file" name="constancia" class="span10 m-wrap"/>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="control-group">
                                                <label class="control-label" <?=((bool)VENDOR_REQ_OC==true && !file_is_valid($record['opinionCumplimiento'])) ? 'style="color:#da4f49;";' : '';?>>Opinión del Cumplimiento (D32)</label>
                                                <div class="controls">
                                                    <?php if( file_is_valid($record['opinionCumplimiento']) ) { ?>
                                                        <a href="file.download.php?f=<?=base64_encode($record['opinionCumplimiento']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                    <?php } else { ?>
                                                        <input type="file" name="opinionCumplimiento" class="span10 m-wrap"/>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="control-group">
                                                <label class="control-label" <?=((bool)VENDOR_REQ_EC==true && !file_is_valid($record['estadoDeCuenta'])) ? 'style="color:#da4f49;";' : '';?>>Carátula Estado de Cuenta</label>
                                                <div class="controls">
                                                    <?php if( file_is_valid($record['estadoDeCuenta']) ) { ?>
                                                        <a href="file.download.php?f=<?=base64_encode($record['estadoDeCuenta']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                    <?php } else { ?>
                                                        <input type="file" name="estadoDeCuenta" class="span10 m-wrap"/>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="control-group">
                                                <label class="control-label" <?=((bool)VENDOR_REQ_EC==true && !file_is_valid($record['identificacion'])) ? 'style="color:#da4f49;";' : '';?>>Identificación con firma</label>
                                                <div class="controls">
                                                    <?php if( file_is_valid($record['identificacion']) ) { ?>
                                                        <a href="file.download.php?f=<?=base64_encode($record['identificacion']);?>&t=o" title="Descargar"><img src="images/icon_pdf.png" /></a>
                                                    <?php } else { ?>
                                                        <input type="file" name="identificacion" class="span10 m-wrap"/>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        <?php } ?>
                                        <div class="control-group">
                                            <label class="control-label">Contraseña (Solo si desea cambiar)</label>
                                            <div class="controls">
                                                <input type="password" name="pswd" class="span10 m-wrap" />
                                            </div>
                                        </div>
                                        <div class="control-group">
                                            <label class="control-label">&nbsp;</label>
                                            <div class="controls">
                                                <button type="submit" class="btn btn-primary"><i class="icon-pencil icon-white"></i> Guardar</button>
                                                <?php if(get_vendor_type($record['rfc'])=="pm" && file_is_valid($record['acta'])) { ?>
                                                    <a href="#delActa" data-toggle="modal" class="btn"><i class="icon-file"></i> Eliminar Acta Constitutiva</a>
                                                    <div id="delActa" class="modal hide">
                                                        <div class="modal-header">
                                                            <button data-dismiss="modal" class="close" type="button">&times;</button>
                                                            <h3>Eliminar Acta</h3>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Está seguro que desea eliminar el acta constitutiva?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <a class="btn btn-primary" href="mod/vendors.info.php?cmd=delacta">Confirmar</a>
                                                            <a data-dismiss="modal" class="btn" href="#">Cancelar</a>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?php if(file_is_valid($record['constancia'])) { ?>
                                                    <a href="#delConstancia" data-toggle="modal" class="btn"><i class="icon-file"></i> Eliminar Constancia</a>
                                                    <div id="delConstancia" class="modal hide">
                                                        <div class="modal-header">
                                                            <button data-dismiss="modal" class="close" type="button">&times;</button>
                                                            <h3>Eliminar Constancia</h3>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Está seguro que desea eliminar la constancia?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <a class="btn btn-primary" href="mod/vendors.info.php?cmd=delcon">Confirmar</a>
                                                            <a data-dismiss="modal" class="btn" href="#">Cancelar</a>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?php if(file_is_valid($record['opinionCumplimiento'])) { ?>
                                                    <a href="#delOpinion" data-toggle="modal" class="btn"><i class="icon-file"></i> Eliminar Opinión de Cumplimiento</a>
                                                    <div id="delOpinion" class="modal hide">
                                                        <div class="modal-header">
                                                            <button data-dismiss="modal" class="close" type="button">&times;</button>
                                                            <h3>Eliminar Opinión de Cumplimiento</h3>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Está seguro que desea eliminar la Opinión de Cumplimiento?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <a class="btn btn-primary" href="mod/vendors.info.php?cmd=delopn">Confirmar</a>
                                                            <a data-dismiss="modal" class="btn" href="#">Cancelar</a>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?php if(file_is_valid($record['estadoDeCuenta'])) { ?>
                                                    <a href="#delEstado" data-toggle="modal" class="btn"><i class="icon-file"></i> Eliminar Estado de Cuenta</a>
                                                    <div id="delEstado" class="modal hide">
                                                        <div class="modal-header">
                                                            <button data-dismiss="modal" class="close" type="button">&times;</button>
                                                            <h3>Eliminar Estado de Cuenta</h3>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Está seguro que desea eliminar el Estado de Cuenta?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <a class="btn btn-primary" href="mod/vendors.info.php?cmd=deledo">Confirmar</a>
                                                            <a data-dismiss="modal" class="btn" href="#">Cancelar</a>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                                <?php if(file_is_valid($record['identificacion'])) { ?>
                                                    <a href="#delIden" data-toggle="modal" class="btn"><i class="icon-file"></i> Eliminar Identificación</a>
                                                    <div id="delIden" class="modal hide">
                                                        <div class="modal-header">
                                                            <button data-dismiss="modal" class="close" type="button">&times;</button>
                                                            <h3>Eliminar Identificación</h3>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Está seguro que desea eliminar la Identificación?</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <a class="btn btn-primary" href="mod/vendors.info.php?cmd=delid">Confirmar</a>
                                                            <a data-dismiss="modal" class="btn" href="#">Cancelar</a>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </fieldset>
                                </form>
                                <!-- ./add-form -->
                                
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                    <!-- ./row -->
                </div><!-- ./content span9 -->

            </div><!-- ./row top -->

            <hr>
            <footer>
                <p> <?=SITE_FOOTER_COPY;?></p>
            </footer>
        </div><!--/.fluid-container-->

        <!-- extra js -->
        <script type="text/javascript" src="vendors/jquery-validation/dist/jquery.validate.min.js"></script>
        <script>

            $(document).ready(function() {

                $('#form_add').validate({
                    errorClass: 'help-inline',
                    rules: {
                        permisoKey: {
                            minlength: 3,
                            required: true
                        },
                        name: {
                            minlength: 4,
                            required: true
                        },
                        archivos: {
                            minlength: 6,
                            required: true
                        }
                    },
                    focusCleanup: false,

                    highlight: function(label) {
                        $(label).closest('.control-group').removeClass('success').addClass('error');
                    },
                    success: function(label) {
                        label
                            .addClass('valid')
                            .closest('.control-group').addClass('success');
                    },
                    errorPlacement: function(error, element) {
                        error.appendTo( element.parents ('.controls') );
                    }
                });

                $('.form').eq (0).find ('input').eq (0).focus ();

            });

        </script>

<?php include("inc.footer.php"); ?>