<?php

# include configuration file
include_once ('../includes/inc.init.php');

# return
$return = "vendors.php";

# process
switch(aglobal('cmd', 20)) {

	case 'add':
	
        if($global_perms['ADD']) {

            # vars
            $error = false;
            $vendor['rfc'] = apost('rfc', 15);
            $vendor['razonSocial'] = apost('razonSocial', 150);
            $vendor['extranjero'] = (int)apost('extranjero');
            $vendor['email'] = apost('email', 150);
            $vendor['banco'] = apost('banco', 100);
            $vendor['cuenta'] = apost('cuenta', 20);
            $vendor['clabe'] = apost('clabe', 20);
            $password = apost('pswd',20);

            # password
            if($password!="") {
                $vendor['password'] = sec_hash_password($password);
            }

            # query
            $id = query_insert(TABLE_VENDORS, $vendor);

            if($id>0) {
                system_log($id, TABLE_VENDORS, "Add", json_encode($vendor));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }
        
        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	case 'update':
	
        if($global_perms['EDIT']) {

            # vars
            $error = false;
            $vendorId = (int)apost('id');
            $vendor['rfc'] = apost('rfc', 15);
            $vendor['razonSocial'] = apost('razonSocial', 150);
            $vendor['extranjero'] = (int)apost('extranjero');
            $vendor['agencia'] = (int)apost('agencia');
            $vendor['email'] = apost('email', 150);
            $vendor['banco'] = apost('banco', 100);
            $vendor['cuenta'] = apost('cuenta', 20);
            $vendor['clabe'] = apost('clabe', 20);
            $vendor['editar'] = (int)apost('editar');
            $password = apost('pswd',20);

            # password
            if($password!="") {
                $vendor['token'] = "";
                $vendor['password'] = sec_hash_password($password);
                query_delete(TABLE_USERS_ATTEMPTS, "usuarioId = $vendorId AND admin = 0");
            }

            # update
            $updated = query_update(TABLE_VENDORS, $vendor, "proveedorId = $vendorId");
                
            if($updated>0) {
                system_log($vendorId, TABLE_VENDORS, "Update", json_encode($vendor));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }
        
        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	case 'del':
    
        if($global_perms['DELETE']) {

            # vars
            $vendorId = (int)aget('id');
            $vendor['deleted'] = 1;

            # query
            $updated = query_update(TABLE_VENDORS, $vendor, "proveedorId = $vendorId");
                
            if($updated>0) {
                system_log($vendorId, TABLE_VENDORS, "Delete", json_encode($vendor));
                set_alert("success", "La información ha sido actualizada.");
            } else {
                set_alert("error", "Hubo un problema, favor de intentar nuevamente");
            }

        } else {
            set_alert("error", "No cuenta con los permisos para acceder a este módulo");
        }

    break;

	default:

        # set error & error message on session
		set_alert("error", "Hubo un problema en la información, por favor intenta nuevamente.");
	
	break;
	
}

# redirect
redirect($return);

?>