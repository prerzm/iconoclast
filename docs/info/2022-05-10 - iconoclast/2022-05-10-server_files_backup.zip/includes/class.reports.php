<?php

# abstract class for reports
abstract class Report {

	protected $name;
	protected $header;
	protected $rows;
	protected $totals;

	abstract public function query($filters);

	public function getName() {

		return $this->name;

	}

	public function getHeader() {

		return $this->header;

	}

	public function displayHeader() {

		if(is_array($this->header)) {
			print "\t<tr>\n";
			foreach($this->header as $th) {
				print "\t<th>$th</th>\n";
			}
			print "\t</tr>\n";
		}

	}

	public function getRows() {

		return $this->rows;

	}

	public function displayRows() {

		if(is_array($this->rows)) {
			foreach($this->rows as $tr) {
				print "\t<tr>\n";
				foreach($tr as $key => $td) {
					if(is_numeric($td)) {
						print "\t<td style=\"text-align:right;\">".number_currency($td)."</td>\n";
					} else {
						print "\t<td>$td</td>\n";
					}
				}
				print "\t</tr>\n";
			}
		} else {
			print "\t<tr><td colspan=\"".count($this->header)."\">No hay resultados</td></tr>\n";
		}

	}

	public function getTotals() {

		return $this->totals;

	}

	public function displayTotals() {

		if(is_array($this->totals) && count($this->totals)>0) {
			print "\t<tr class=\"level_total\">\n";
			foreach($this->totals as $th) {
				if(is_numeric($th)) {
					print "\t<th style=\"background-color:#eaeaea;text-align:right;\">".number_currency($th)."</th>\n";
				} else {
					print "\t<th style=\"background-color:#eaeaea;text-align:right;\">$th</th>\n";
				}
			}
			print "\t</tr>\n";
		}

	}

}
# ./Report


# RepPos - Cuentas por Pagar
class RepPos extends Report {

	public function __construct($filters) {

		$this->name = "Cuentas por Pagar";
		$this->query($filters);

	}

	public function query($filters) {

		# query
		list($this->header, $this->rows, $this->totals) = get_report_pos($filters);

	}

	public function export() {

		get_excel_pos($this->header, $this->rows);

	}

}
# ./RepPos


# RepProy - Proyectos
class RepProy extends Report {

	public function __construct($filters) {

		$this->name = "Proyectos";
		$this->query($filters);

	}

	public function query($filters) {

		# query
		list($this->header, $this->rows, $this->totals) = get_report_proyectos($filters);

	}

	public function export() {

		get_excel_proyectos($this->header, $this->rows);

	}

}


# RepProvs - Proveedores
class RepProvs extends Report {

	public function __construct($filters) {

		$this->name = "Proveedores";
		$this->query($filters);

	}

	public function query($filters) {

		# query
		list($this->header, $this->rows, $this->totals) = get_report_proveedores($filters);

	}

	public function export() {

		get_excel_proveedores($this->header, $this->rows);

	}

}


# RepFlujo - Flujo de efectivo
class RepFlujo extends Report {

	public function __construct($filters) {

		$this->name = "Flujo de Efectivo";
		$this->query($filters);

	}

	public function query($filters) {

		# query
		list($this->header, $this->rows, $this->totals) = get_report_flujo($filters);

	}

	public function export() {

		get_excel_flujo($this->header, $this->rows);

	}

}


?>