<?php

/** Module & menu functions **/

function get_active_menu($filename) {

    $filename = pathinfo($filename, PATHINFO_BASENAME);

    return query_select_single_value("menuParentKey", TABLE_MODULES, "moduloFiles LIKE '%$filename%'");

}

# get modules
function get_modules() {
    return sql_select("SELECT * FROM ".TABLE_MODULES." ORDER BY orden ASC");
}

function get_module($id) {
    return sql_select_row("SELECT * FROM ".TABLE_MODULES." WHERE moduloId = $id");
}


/** Role functions **/

# get roles
function get_roles() {
    return sql_select("SELECT * FROM ".TABLE_ROLES);
}

function get_role($id) {
    return sql_select_row("SELECT * FROM ".TABLE_ROLES." WHERE rolId = $id");
}

function get_role_permissions($roleId) {

    $modules = get_modules();

    for($m=0; $m<count($modules); $m++) {

        $perms[$m]['moduloId'] = $modules[$m]['moduloId'];
        $perms[$m]['modulo'] = $modules[$m]['modulo'];

        $mod_perm = sql_select("SELECT permisoId, permisoKey, permiso FROM ".TABLE_MODULES_PERMS." WHERE moduloId = ".$modules[$m]['moduloId']." ORDER BY permiso ASC");

        if($mod_perm) {
            for($i=0; $i<count($mod_perm); $i++) {
                $rol_perm = sql_select_row("SELECT rolPermisoId FROM ".TABLE_ROLES_PERMS." WHERE rolid = $roleId AND permisoId = ".$mod_perm[$i]['permisoId']);
                if($rol_perm) {
                    $perms[$m]['perms'][] = array("permisoId" => $mod_perm[$i]['permisoId'], "permiso" => $mod_perm[$i]['permiso'], "check" => true);
                } else {
                    $perms[$m]['perms'][] = array("permisoId" => $mod_perm[$i]['permisoId'], "permiso" => $mod_perm[$i]['permiso'], "check" => false);
                }
            }
        } else {
            $perms[$m]['perms'] = array();
        }

    }

    return $perms;

}

# get header menu items based on role, modules & permissions
function role_get_menu($roleId) {

    $menu = sql_select("SELECT DISTINCT menuParentKey, menuParentName 
                        FROM ".TABLE_MODULES." m, ".TABLE_MODULES_PERMS." p, ".TABLE_ROLES_PERMS." rp, ".TABLE_ROLES." r 
                        WHERE m.moduloId = p.moduloId AND p.permisoId = rp.permisoId AND rp.rolId = r.rolId 
                            AND r.rolId = ".session_get_data("roleId")." AND p.permisoKey = 'READ' 
                        ORDER BY m.orden ASC");

    if($menu) {

        for($i=0; $i<count($menu); $i++) {

            $items = sql_select("SELECT m.modulo, m.menuFile  
                                FROM ".TABLE_MODULES." m, ".TABLE_MODULES_PERMS." p, ".TABLE_ROLES_PERMS." rp, ".TABLE_ROLES." r 
                                WHERE m.moduloId = p.moduloId AND p.permisoId = rp.permisoId AND rp.rolId = r.rolId 
                                    AND m.menuParentKey = '".$menu[$i]['menuParentKey']."' AND r.rolId = ".session_get_data("roleId")." AND p.permisoKey = 'READ' 
                                ORDER BY m.orden ASC");
            for($j=0; $j<count($items); $j++) {
                $menu[$i]['items'][] = array("url" => $items[$j]['menuFile'], "item" => $items[$j]['modulo']);
            }

        }

    }

    return $menu;

}



/** Permissions functions **/

# get permissions
function get_permissions() {
    return sql_select("SELECT p.*, m.modulo FROM ".TABLE_MODULES_PERMS." p, ".TABLE_MODULES." m WHERE p.moduloId = m.moduloId");
}
# get permission
function get_permission($id) {
    return sql_select_row("SELECT p.*, m.modulo FROM ".TABLE_MODULES." m, ".TABLE_MODULES_PERMS." p  WHERE m.moduloId = p.moduloId AND permisoId = $id");
}


/** Company functions **/

function get_company_info() {

    $info = sql_select_row("SELECT * FROM ".TABLE_COMPANIES." WHERE companyId = ".(int)COMPANY_ID);
    if($info) {
        $info['direccion'] = json_decode($info['direccion'], true);
        $info['revision'] = json_decode($info['facturasRevision'], true);
    }

    return $info;

}


/** Budgets functions **/

function get_budgets_all() {
    return sql_select("SELECT   b.presupuestoId, b.fechaDeRodaje, p.proyectoId, p.titulo, 
                                c.razonSocial, d.directorNombre, CONCAT(p.titulo, ' - ', LPAD(b.numero, 2, '0')) AS referencia 
                        FROM ".TABLE_PROJECTS_BUDGETS." b, ".TABLE_PROJECTS." p, ".TABLE_CUSTOMERS." c, ".TABLE_DIRECTORS." d 
                        WHERE b.proyectoId = p.proyectoId AND p.cuentaId = c.cuentaId AND p.directorId = d.directorId AND p.deleted = 0 AND p.activo = 1");
}

function get_budgets($projectId, $customerId, $directorId, $dateFrom, $dateTo) {

    $sql_project = "";
    if($projectId>0) {
        $sql_project = " AND b.proyectoId = $projectId";
    }

    $sql_customer = "";
    if($customerId>0) {
        $sql_customer = " AND p.cuentaId = $customerId";
    }

    $sql_director = "";
    if($directorId>0) {
        $sql_director = " AND b.directorId = $directorId";
    }

    $sql_date = " AND b.fechaDeRodaje BETWEEN '$dateFrom' AND '$dateTo'";

    return sql_select(" SELECT  b.presupuestoId, b.diasFilmacion, b.fechaDeRodaje, p.proyectoId, 
                                p.titulo, c.razonSocial, d.directorNombre, CONCAT(p.titulo, ' - ', LPAD(b.numero, 2, '0')) AS referencia, 
                                SUM(bi.total) AS total 
                        FROM ".TABLE_PROJECTS_BUDGETS." b, ".TABLE_PROJECTS." p, ".TABLE_CUSTOMERS." c, ".TABLE_DIRECTORS." d, ".TABLE_PROJECTS_BUDGETS_ITEMS." bi 
                        WHERE b.proyectoId = p.proyectoId AND p.cuentaId = c.cuentaId AND b.directorId = d.directorId AND b.presupuestoId = bi.presupuestoId AND 
                            p.deleted = 0 AND p.activo = 1
                            $sql_project $sql_customer $sql_director $sql_date 
                        GROUP BY b.presupuestoId
                    ");

}

function get_budget($budgetId) {
    return sql_select_row("SELECT *, LPAD(numero, 2, '0') AS referencia FROM ".TABLE_PROJECTS_BUDGETS." WHERE presupuestoId = $budgetId");
}

function get_budget_item_id($budgetId, $concepto) {

    $concepto = explode(" ", $concepto);

    if(is_array($concepto) && isset($concepto[0]) && (int)trim($concepto[0])>0) {
        return (int)query_select_single_value("itemId", TABLE_PROJECTS_BUDGETS_ITEMS, "presupuestoId = $budgetId AND cuenta = ".(int)trim($concepto[0]));
    } else {
        return (int)query_select_single_value("itemId", TABLE_PROJECTS_BUDGETS_ITEMS, "presupuestoId = $budgetId");
    }

}

# get budget's next numero
function get_budget_name($budgetId) {

    return query_select_single_value(	"CONCAT(p.proyectoId, '.', pp.numero, ' ', p.titulo)", 
                                        TABLE_PROJECTS." p, ".TABLE_PROJECTS_BUDGETS." pp", 
                                        "p.proyectoId = pp.proyectoId AND pp.presupuestoId = ".$budgetId
                                    );

}

function get_budget_next_num($projectId) {
    
    $num = (int)query_select_single_value("(numero+1) AS numero", TABLE_PROJECTS_BUDGETS, "proyectoId = $projectId", "numero DESC");

    if($num==0) {
        return 1;
    } else {
        return $num;
    }

}

function get_budget_items($budgetId, $selectedId=0) {

    return sql_select("SELECT i.itemId, i.presupuestoId, i.conceptoId, i.parentId, i.categoria, i.nivel, CONCAT(i.cuenta, ' - ', i.nombre) AS concepto, i.moneda 
                        FROM ".TABLE_PROJECTS_BUDGETS_ITEMS." i
                        WHERE i.presupuestoId = $budgetId 
                        ORDER BY i.cuenta ASC, i.categoria DESC, i.nivel ASC");
    
}

# get project's budget select options
function get_budget_options($budgetId, $selectedId) {

    $options = "";
    $results = sql_select("SELECT itemId, conceptoId, categoria, nivel, CONCAT(cuenta, ' - ', nombre) AS concepto
                            FROM ".TABLE_PROJECTS_BUDGETS_ITEMS." WHERE presupuestoId = $budgetId AND nivel < 2 
                            ORDER BY cuenta ASC, categoria DESC, nivel ASC");
    
    if($results) {
        for($i=0; $i<count($results); $i++) {
            if($results[$i]['conceptoId']==$selectedId) {
                $options .= '<option value="'.$results[$i]['conceptoId'].'" selected>'.space_by_level($results[$i]['nivel']).$results[$i]['concepto']."</option>\n";
            } else {
                $options .= '<option value="'.$results[$i]['conceptoId'].'">'.space_by_level($results[$i]['nivel']).$results[$i]['concepto']."</option>\n";
            }
        }
    }

    return $options;

}

# get budgets table rows
function get_budget_table_rows($budgetId, $monedas) {

    $rows = "";
    $results = sql_select("SELECT * FROM ".TABLE_PROJECTS_BUDGETS_ITEMS." 
                            WHERE presupuestoId = $budgetId 
                            ORDER BY cuenta ASC, categoria DESC, nivel ASC, itemId ASC");

    if(is_array($results) && count($results)>0) {

        $budget_total = 0;
        
        for($i=0; $i<count($results); $i++) {

            $itemId = $results[$i]['itemId'];
            $conceptoId = $results[$i]['conceptoId'];
            $categoria = $results[$i]['categoria'];
            $nivel = $results[$i]['nivel'];
            $concepto = $results[$i]['cuenta'].' - '.$results[$i]['nombre'];
            $moneda = $results[$i]['moneda'];
            $monto = $results[$i]['monto'];
            $rate = (isset($monedas[$moneda])) ? $monedas[$moneda] : 1;
            $total = $monto * $rate;

            $budget_total += $total;

            if($categoria==1) {
                $rows .= "\t".'<tr class="level_'.$nivel.'">';
                $rows .= '<td style="white-space:nowrap;">'.space_by_level($nivel).$concepto."</td>";
                $rows .= '<td style="border-left:none;">&nbsp;</td>';
                $rows .= '<td style="border-left:none;">&nbsp;</td>';
                $rows .= '<td style="border-left:none;">&nbsp;</td>';
                $rows .= '<td style="border-left:none;">&nbsp;</td>';
                $rows .= '</tr>'."\n";
            } else {
                $rows .= "\t".'<tr class="level_'.$nivel.'">';
                $rows .= '<td>'.space_by_level($nivel).$concepto.'</td>';
                $rows .= '<td><select id="moneda_'.$itemId.'" name="monedas['.$itemId.']" style="width:65px;" onchange="calc_totals('.$itemId.');">';
                foreach($monedas as $key => $tc) {
                    $rows .= ($key==$moneda) ? '<option value="'.$key.'" selected>'.$key.'</option>' : '<option value="'.$key.'">'.$key.'</option>';
                }
                $rows .= '</select></td>';
                $rows .= '<td><input type="text" id="monto_'.$itemId.'" name="montos['.$itemId.']" value="'.$monto.'" onchange="calc_totals('.$itemId.');"></td>';
                $rows .= '<td id="row_td_total_'.$itemId.'">'.number_currency($total).'</td>';
                $rows .= '<td><a href="mod/budgets.php?cmd=item_del&id='.$budgetId.'&iid='.$itemId.'" title="Eliminar" onclick="return confirm(\'Está seguro que desea eliminar este rubro?\');"><img src="images/silk/cross.png" /></a></td>';
                $rows .= '</tr>'."\n";
            }

        }

        # row total
        $rows .= "\t".'<tr class="level_total">';
        $rows .= '<td style="border-top: 2px solid #7c7c7c;">&nbsp;</td>';
        $rows .= '<td style="border-left:none;border-top: 2px solid #7c7c7c;">&nbsp;</td>';
        $rows .= '<td style="border-left:none;border-top: 2px solid #7c7c7c;">Total</td>';
        $rows .= '<td style="border-left:none;border-top: 2px solid #7c7c7c;" id="budget_total">'.number_currency($budget_total).'</td>';
        $rows .= '<td style="border-left:none;border-top: 2px solid #7c7c7c;">&nbsp;</td>';
        $rows .= '</tr>'."\n";

    }

    return $rows;

}

# get next conceptoId by budget
function get_next_conceptoId($budgetId) {
    return (int)query_select_single_value("(conceptoId+1) AS conceptoId", TABLE_PROJECTS_BUDGETS_ITEMS, "presupuestoId = $budgetId", "conceptoId DESC");
}

function get_budget_search_date_from($date) {
    if(strtotime($date)==false) {
        $date = date("Y-m-01", strtotime(date("Y-m-d")." -3 months"));
    }
    return $date;
}

function get_budget_search_date_to($date) {
    if(strtotime($date)==false) {
        $date = date("Y-m-t", strtotime(date("Y-m-d")." +3 months"));
    }
    return $date;
}

# insert spaces &nbsp; in str based on cat level 0-2
function space_by_level($level) {
    $level *= 3;
    $str = "";
    for ($i=0; $i<$level; $i++) { 
        $str .= "&nbsp;";
    }
    return $str;
}

# load master budget into project's budget
function load_master_budget($projectId, $budgetId) {
    sql_query("INSERT INTO ".TABLE_PROJECTS_BUDGETS_ITEMS." (proyectoId, presupuestoId, conceptoId, parentId, categoria, nivel, cuenta, nombre) 
                SELECT $projectId, $budgetId, conceptoId, parentId, categoria, nivel, cuenta, nombre FROM ".TABLE_MASTER);
}

# get master budget's cats and subcats only (select options)
function get_master_budget_select_options($parentId) {

    $options = "";
    $results = sql_select("SELECT conceptoId, categoria, nivel, CONCAT(cuenta, ' - ', nombre) AS concepto
                            FROM ".TABLE_MASTER." WHERE nivel < 2 
                            ORDER BY cuenta ASC, categoria DESC, nivel ASC");
    
    if($results) {
        for($i=0; $i<count($results); $i++) {
            if($results[$i]['conceptoId']==$parentId) {
                $options .= '<option value="'.$results[$i]['conceptoId'].'" selected>'.space_by_level($results[$i]['nivel']).$results[$i]['concepto']."</option>\n";
            } else {
                $options .= '<option value="'.$results[$i]['conceptoId'].'">'.space_by_level($results[$i]['nivel']).$results[$i]['concepto']."</option>\n";
            }
        }
    }

    return $options;

}

# get all master budget's cats, subcats & concepts (table rows)
function get_master_budget_table_rows() {

    # vars
    global $global_perms;
    $rows = "";
    $results = sql_select("SELECT conceptoId, categoria, nivel, CONCAT(cuenta, ' - ', nombre) AS concepto 
                            FROM ".TABLE_MASTER." ORDER BY cuenta ASC, categoria DESC, nivel ASC");
    
    if($results) {

        for($i=0; $i<count($results); $i++) {

            $conceptoId = $results[$i]['conceptoId'];
            $categoria = $results[$i]['categoria'];
            $nivel = $results[$i]['nivel'];
            $concepto = $results[$i]['concepto'];;

            if($categoria==1) {
                $rows .= "\t<tr class=\"level_$nivel\">";
                $rows .= '<td>'.space_by_level($nivel).$concepto.'</td>';
                $rows .= '<td>';
                $rows .= ($global_perms['EDIT']) ? '<a href="master.edit.php?id='.$conceptoId.'" title="Editar"><img src="images/silk/pencil.png" /></a>' : '';
                $rows .= '</td>';
                $rows .= "</tr>\n";
            } else {
                $rows .= "\t<tr>";
                $rows .= '<td>'.space_by_level($nivel).$concepto.'</td>';
                $rows .= '<td>';
                $rows .= ($global_perms['EDIT']) ? '<a href="master.edit.php?id='.$conceptoId.'" title="Editar"><img src="images/silk/pencil.png" /></a>&nbsp;' : '';
                $rows .= ($global_perms['DELETE']) ? '<a href="mod/master.php?cmd=del&id='.$conceptoId.'" title="Eliminar" onclick="return confirm(\'Está seguro que desea eliminar este registro?\');"><img src="images/silk/cross.png" /></a>' : '';
                $rows .= '</td>';
                $rows .= "</tr>\n";
            }

        }

    }

    return $rows;

}

function add_budget($projectId, $directorId, $days, $date) {

    $budget['proyectoId'] = (int)$projectId;
    $budget['numero'] = get_budget_next_num($projectId);
    $budget['directorId'] = (int)$directorId;
    $budget['diasFilmacion'] = (int)$days;
    $budget['fechaDeRodaje'] = $date;

    $budgetId = query_insert(TABLE_PROJECTS_BUDGETS, $budget);

    if($budgetId>0) {

        # load master budget
        load_master_budget($projectId, $budgetId);

    }

    return $budgetId;

}

function budget_create_cierre_file($budgetId) {

    $budget = get_budget($budgetId);
    $budget_items = get_budget_items($budgetId);
    $project = get_project($budget['proyectoId']);
    $director = get_director($budget['directorId']);
    $cuenta = get_customer($project['cuentaId']);

    # Create PHPExcel object
    $objPHPExcel = new PHPExcel();

    # vars
    $currentRow = 2;
    
    # Set document properties
    $objPHPExcel->getProperties()->setCreator(session_get_data("name"))
                                ->setLastModifiedBy(session_get_data("name"))
                                ->setTitle("Cierre de Presupuesto");

    # Title
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$currentRow, 'LISTA DE CHEQUES');
    $objPHPExcel->getActiveSheet()->getStyle('B'.$currentRow)->applyFromArray( get_style("cierreTitle") );
    $currentRow += 2;

    # Info
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$currentRow, 'CLAVE');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$currentRow, $project['clave']);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$currentRow.':C'.$currentRow)->applyFromArray( get_style("cierreSubtitle") );
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$currentRow, 'PRESUPUESTO');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$currentRow, $budgetId);
    $objPHPExcel->getActiveSheet()->getStyle('F'.$currentRow.':G'.$currentRow)->applyFromArray( get_style("cierreSubtitle") );
    $currentRow++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$currentRow, 'PROYECTO');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$currentRow, $project['titulo']);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$currentRow.':C'.$currentRow)->applyFromArray( get_style("cierreSubtitle") );
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$currentRow, 'CUENTA');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$currentRow, $cuenta['razonSocial']);
    $objPHPExcel->getActiveSheet()->getStyle('F'.$currentRow.':G'.$currentRow)->applyFromArray( get_style("cierreSubtitle") );
    $currentRow++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$currentRow, 'PRODUCTO');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$currentRow, $project['producto']);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$currentRow.':C'.$currentRow)->applyFromArray( get_style("cierreSubtitle") );
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$currentRow, 'CLIENTE');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$currentRow, $project['cliente']);
    $objPHPExcel->getActiveSheet()->getStyle('F'.$currentRow.':G'.$currentRow)->applyFromArray( get_style("cierreSubtitle") );
    $currentRow++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$currentRow, 'FECHA FILMACIÓN');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$currentRow, $budget['fechaDeRodaje']);
    $objPHPExcel->getActiveSheet()->getStyle('B'.$currentRow.':C'.$currentRow)->applyFromArray( get_style("cierreSubtitle") );
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$currentRow, 'DIRECTOR');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$currentRow, $director['directorNombre']);
    $objPHPExcel->getActiveSheet()->getStyle('F'.$currentRow.':G'.$currentRow)->applyFromArray( get_style("cierreSubtitle") );

    $currentRow += 2;

    # Data header
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$currentRow, 'RFC');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('B'.$currentRow, 'Razon Social');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('C'.$currentRow, 'Nombre y Puesto');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$currentRow, 'Concepto');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('E'.$currentRow, 'Mail');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('F'.$currentRow, 'Comprobante');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('G'.$currentRow, 'Costo Unitario');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('H'.$currentRow, 'Dias');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('I'.$currentRow, 'Horas Extra');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('J'.$currentRow, 'Monto');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('K'.$currentRow, 'IVA');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('L'.$currentRow, 'Ret IVA');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('M'.$currentRow, 'Ret ISR');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('N'.$currentRow, 'Total');

    $objPHPExcel->getActiveSheet()->getStyle('A'.$currentRow.':n'.$currentRow)->applyFromArray( get_style("cierreHeader") );

    # Set columns widths
    $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
    $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
    
    $currentRow++;
    
    # Conceptos
    if($budget_items) {

        $dataStartRow = $currentRow;

        for($i=0; $i<count($budget_items); $i++, $currentRow++) {

            $objPHPExcel->setActiveSheetIndex(0)->setCellValue('D'.$currentRow, $budget_items[$i]['concepto']);

            # Set formulas
            $objPHPExcel->getActiveSheet()->setCellValue("J".$currentRow, "=(G".$currentRow."*H".$currentRow.")+I".$currentRow);
            $objPHPExcel->getActiveSheet()->setCellValue("K".$currentRow, "=J".$currentRow."*".TAX_IVA);
            $objPHPExcel->getActiveSheet()->setCellValue("L".$currentRow, "=IF(F".$currentRow."=\"R\",K".$currentRow."/3*2,0)");
            $objPHPExcel->getActiveSheet()->setCellValue("M".$currentRow, "=IF(F".$currentRow."=\"R\",J".$currentRow."*".TAX_ISR.",0)");
            $objPHPExcel->getActiveSheet()->setCellValue("N".$currentRow, "=J".$currentRow."+K".$currentRow."-L".$currentRow."-M".$currentRow."");
            
        }

        # Set formats
		$objPHPExcel->getActiveSheet()->getStyle("G".$dataStartRow.":N".$currentRow)->getNumberFormat()->setFormatCode('#,##0.00');

    }

    #$currentRow = $dataStartRow;

    # Set headers to send file
    header('Content-type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="Cierre Presupuesto '.$project['clave'].'.xlsx"');
    
    # Save & Send Excel 2007
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
    $objWriter->save('php://output');
        
}


/** Projects functions **/

# get all visible projects
function get_projects_visible() {
    return sql_select("SELECT * FROM ".TABLE_PROJECTS." WHERE activo = 1 AND deleted = 0");
}

function get_projects_all() {
    return sql_select("SELECT * FROM ".TABLE_PROJECTS." WHERE deleted = 0");
}

# get project
function get_project($projectId) {
    
    return sql_select_row(" SELECT *, 
                                    CONCAT('".PATH_PROJECTS."', uniqId, '/facturas/') AS pathFacturas, 
                                    CONCAT('".PATH_PROJECTS."', uniqId, '/transfers/') AS pathTransfers, 
                                    CONCAT('".PATH_PROJECTS."', uniqId, '/cierres/') AS pathCierres, 
                                    CONCAT('".PATH_PROJECTS."', uniqId, '/comprobantes/') AS pathComprobantes, 
                                    CONCAT('".PATH_PROJECTS."', uniqId, '/firmas/') AS pathFirmas, 
                                    CONCAT('".PATH_PROJECTS."', uniqId, '/contratos/') AS pathContratos 
                                FROM ".TABLE_PROJECTS." 
                                WHERE proyectoId = $projectId
                            ");

}

# create folders
function project_create_paths($uniqId) {

    if( file_exists(PATH_PROJECTS) && is_dir(PATH_PROJECTS) ) {
        
        $project_path = PATH_PROJECTS.$uniqId."/";

        if( !file_exists($project_path) ) {
            mkdir($project_path);
            mkdir($project_path."facturas");
            mkdir($project_path."transfers");
            mkdir($project_path."cierres");
            mkdir($project_path."contratos");
        } else {
            if( !file_exists($project_path."facturas") ) {  mkdir($project_path."facturas"); }
            if( !file_exists($project_path."transfers") ) {  mkdir($project_path."transfers"); }
            if( !file_exists($project_path."cierres") ) {  mkdir($project_path."cierres"); }
            if( !file_exists($project_path."contratos") ) {  mkdir($project_path."contratos"); }
        }

    } else {
        die("projects path missing...");
    }

}

# get concept info
function get_concept_info($itemId) {
    
    return sql_select_row("SELECT * FROM ".TABLE_PROJECTS_BUDGETS_ITEMS." WHERE itemId = $itemId");

}

# update concept with prepared statement (updating 500+ records)
function concept_update($itemId, $moneda, $monto, $total) {

    global $mysqli;

	// Using prepared statements means that SQL injection is not possible. 
    if ($stmt = $mysqli->prepare("UPDATE ".TABLE_PROJECTS_BUDGETS_ITEMS." SET moneda = ?, monto = ?, total = ? WHERE itemId = ?")) {

		$stmt->bind_param('sddi', $moneda, $monto, $total, $itemId);
        $stmt->execute();
        return @$mysqli->affected_rows;
	
	} else {

		// Prepared statement failed - Set error message
		set_alert("error", "Hubo un problema en la información, por favor intenta nuevamente.");
		return false;

	}
	
}

# get concept children
function get_concept_children($budgetId, $parentId) {
    
    return sql_select("SELECT * FROM ".TABLE_PROJECTS_BUDGETS_ITEMS." WHERE presupuestoId = $budgetId AND parentId = $parentId");

}

function set_concept_as_child($budgetId, $conceptId) {

    return query_update(TABLE_PROJECTS_BUDGETS_ITEMS, array("categoria" => 0), "presupuestoId = $budgetId AND conceptoId = $conceptId");

}

/** Customers functions **/

function get_customers() {
    return sql_select("SELECT * FROM ".TABLE_CUSTOMERS." WHERE deleted = 0");
}

function get_customer($customerId) {
    return sql_select_row("SELECT * FROM ".TABLE_CUSTOMERS." WHERE cuentaId = $customerId");
}


/** Directors functions */

function get_directors_visible() {
    return sql_select("SELECT * FROM ".TABLE_DIRECTORS." WHERE activo = 1 AND deleted = 0");
}

function get_directors_all() {
    return sql_select("SELECT * FROM ".TABLE_DIRECTORS." WHERE deleted = 0");
}

function get_director($directorId) {
    return sql_select_row("SELECT * FROM ".TABLE_DIRECTORS." WHERE directorId = $directorId");
}


/** Vendor functions **/

function get_vendors() {
    return sql_select("SELECT * FROM ".TABLE_VENDORS." WHERE deleted = 0 ORDER BY razonSocial ASC");
}

function get_vendors_in_active_project() {
    return sql_select("SELECT DISTINCT v.proveedorId, v.razonSocial  
                        FROM ".TABLE_POS." g, ".TABLE_PROJECTS." p, ".TABLE_VENDORS." v
                        WHERE g.proyectoId = p.proyectoId AND g.proveedorId = v.proveedorId AND p.activo = 1
                        ORDER BY v.razonSocial ASC");
}

function get_vendor($vendorId) {
    return sql_select_row(" SELECT proveedorId, rfc, razonSocial, extranjero, agencia, email, banco, cuenta, clabe, editar, 
                                IF(acta <> '', CONCAT('".PATH_VENDORS."', acta), FALSE) AS acta, 
                                IF(constancia <> '', CONCAT('".PATH_VENDORS."', constancia), FALSE) AS constancia, 
                                IF(opinionCumplimiento <> '', CONCAT('".PATH_VENDORS."', opinionCumplimiento), FALSE) AS opinionCumplimiento, 
                                IF(estadoDeCuenta <> '', CONCAT('".PATH_VENDORS."', estadoDeCuenta), FALSE) AS estadoDeCuenta, 
                                IF(identificacion <> '', CONCAT('".PATH_VENDORS."', identificacion), FALSE) AS identificacion
                            FROM ".TABLE_VENDORS." 
                            WHERE proveedorId = $vendorId
                        ");
}

function get_vendor_type($rfc) {

    $char = substr($rfc, 3, 1);

    if(is_numeric($char)) {
        return "pm";
    } else {
        return "pf";
    }

}

function get_vendor_id($rfc) {
    return (int)query_select_single_value("proveedorId", TABLE_VENDORS, "rfc = '$rfc' AND deleted = 0");
}

function get_vendor_po_info($poId) {

    return sql_select_row(" SELECT 	g.gastoId, g.concepto, IF(g.fechaDePago IS NULL, '-', g.fechaDePago) AS fechaDePago, 
                                    g.moneda, g.tipoDeCambio, g.monto, g.iva, g.retIVA, g.retISR, g.total, g.totalMXN, 
                                    g.pagoFormaId, g.pagoMetodoId, g.usoCfdiId, 
                                    p.proyectoId, CONCAT(p.clave, ' - ', p.titulo) AS proyecto, 
                                    g.facturaUuid, g.facturaInfo, g.referencia, g.notas, 
                                    CONCAT('".PATH_PROJECTS."', p.uniqId, '/facturas/', g.facturaNombre, '.pdf') AS facturaPDF, 
                                    CONCAT('".PATH_PROJECTS."', p.uniqId, '/facturas/', g.facturaNombre, '.xml') AS facturaXML, 
                                    CONCAT('".PATH_PROJECTS."', p.uniqId, '/transfers/', g.transfer) AS transfer, 
                                    CONCAT('".PATH_PROJECTS."', p.uniqId, '/comprobantes/', g.comprobante, '.pdf') AS comprobantePDF, 
                                    CONCAT('".PATH_PROJECTS."', p.uniqId, '/comprobantes/', g.comprobante, '.xml') AS comprobanteXML, 
                                    pf.claveFormaPago, CONCAT(pf.claveFormaPago, ' - ', pf.pagoForma) AS pagoForma, 
                                    pm.claveMetodoPago, CONCAT(pm.claveMetodoPago, ' - ', pm.pagoMetodo) AS pagoMetodo, 
                                    pu.claveUso, CONCAT(pu.claveUso, ' - ', pu.uso) AS usoCfdi, 
                                    ps.pagoStatusId, ps.pagoStatus, 
                                    v.rfc, v.razonSocial, v.extranjero, v.email, v.banco, v.cuenta, v.clabe 
                            FROM    ".TABLE_SAT_FORMA_PAGO." pf, ".TABLE_SAT_METODO_PAGO." pm, ".TABLE_SAT_USO_CFDI." pu, 
                                    ".TABLE_PAYMENTS_STATUS." ps, ".TABLE_VENDORS." v, ".TABLE_POS." g, ".TABLE_PROJECTS." p 
                            WHERE   g.proyectoId = p.proyectoId AND pf.pagoFormaId = g.pagoFormaId AND pm.pagoMetodoId = g.pagoMetodoId AND 
                                    pu.usoCfdiId = g.usoCfdiId AND ps.pagoStatusId = g.pagoStatusId AND g.proveedorId = v.proveedorId AND 
                                    g.proveedorId = ".session_get_data("userId")." AND g.gastoId = $poId 
                        ");

}

function vendor_document_upload($vendorId, $doc) {
    
    if($doc=="constancia") {
        $id = "C";
    } elseif($doc=="opinionCumplimiento") {
        $id = "O";
    } elseif($doc=="estadoDeCuenta") {
        $id = "E";
    } elseif($doc=="identificacion") {
        $id = "ID";
    } elseif($doc=="acta") {
        $id = "AC";
    }

    $document = ( isset($_FILES[$doc]) && $_FILES[$doc]['size']>0 && $_FILES[$doc]['error']==0) ? $_FILES[$doc] : false;

    if($document!==false) {

        $new_file_name = $vendorId."_".$id."_".$document['name'];

        if(file_upload($document['tmp_name'], PATH_VENDORS, $new_file_name)===true) {
            return $new_file_name;
        }

    }

    return false;

}

function vendor_verify_info($vendorId) {

    # vars
    $missing_info = false;
    $vendor = get_vendor($vendorId);

    # datos bancarios
    if(var_is_empty($vendor['banco']) || var_is_empty($vendor['cuenta']) || var_is_empty($vendor['clabe'])) {
        $missing_info = true;
        set_alert("warning", "La información de tus datos bancarios está incompleta, es necesario que la completes para poder recibir cualquier pago.");
    }

    if($vendor['extranjero']==0) {

        # csf
        if((bool)VENDOR_REQ_CSF==true && !file_is_valid($vendor['constancia'])) {
            $missing_info = true;
            set_alert("warning", "Tu documentación está incompleta, la Constancia de Situación Fiscal es necesaria para poder recibir cualquier pago.");
        }

        # oc
        if((bool)VENDOR_REQ_OC==true && !file_is_valid($vendor['opinionCumplimiento'])) {
            $missing_info = true;
            set_alert("warning", "Tu documentación está incompleta, la Opinión del Cumplimiento (D32) es necesaria para poder recibir cualquier pago.");
        }

        # ec
        if((bool)VENDOR_REQ_EC==true && !file_is_valid($vendor['estadoDeCuenta'])) {
            $missing_info = true;
            set_alert("warning", "Tu documentación está incompleta, el Estado de Cuenta es necesario para poder recibir cualquier pago.");
        }

        # id
        if((bool)VENDOR_REQ_ID==true && !file_is_valid($vendor['identificacion'])) {
            $missing_info = true;
            if(get_vendor_type($vendor['rfc'])=="pm") {
                set_alert("warning", "Tu documentación está incompleta, la Identificación del representante legal es necesaria para poder recibir cualquier pago.");
            } else {
                set_alert("warning", "Tu documentación está incompleta, la Identificación es necesaria para poder recibir cualquier pago.");
            }
        }

        if($missing_info==true) {
            redirect("vendors.info.php");
        }

    }
    
}

function vendor_verify_contract_signed($vendorId, $projectId) {
    $status = query_select_single_value("firmaStatusId", TABLE_CONTRACTS_VENDORS, "proveedorId = $vendorId AND proyectoId = $projectId");
    if((int)$status==CONTRACT_STATUS_PENDING) {
        return false;
    }
    return true;
}

function vendor_allow_edit_info($vendorId) {

    $pos = sql_select("SELECT gastoId FROM ".TABLE_POS." WHERE proveedorId = $vendorId AND fechaDePago = '".date("Y-m-d")."'");

    if($pos) {
        return false;
    }

    return true;

}

function get_vendors_exist() {

    $results = sql_select_row("SELECT COUNT(*) AS total FROM ".TABLE_VENDORS." WHERE deleted = 0");
    return ((int)$results['total']==0) ? false : true;

}

function get_vendor_po_allow_edit($pagoMetodoId, $facturaUuid, $pagoStatusId, $comprobanteXML) {

    if($facturaUuid=="") {
        return true;
    }

    if($pagoMetodoId==FACTURAS_TIPO_REVISION && $pagoStatusId==PAYMENT_STATUS_PAYED && !file_is_valid($comprobanteXML)) {
        return true;
    }

    return false;

}

function vendor_is_foreign($vendorId) {
    return (bool)query_select_single_value("extranjero", TABLE_VENDORS, "proveedorId = $vendorId");
}

function vendor_last_pos($vendorId, $projectId) {
    $query = sql_select_row("SELECT COUNT(gastoId) AS total FROM ".TABLE_POS." WHERE proveedorId = $vendorId AND proyectoId = $projectId");
    if($query && $query['total']<=1) {
        return true;
    }
    return false;
}

/** POs functions **/

function get_pos($projectId, $vendor, $statusId, $factura, $dateFrom, $dateTo) {

    $sql_project = "";
    if($projectId>0) {
        $sql_project = " AND g.proyectoId = $projectId";
    }

    $sql_vendor = "";
    if($vendor!="") {
        $sql_vendor = " AND (v.rfc LIKE '%$vendor%' OR v.razonSocial LIKE '%$vendor%' OR v.email LIKE '%$vendor%')";
    }

    $sql_status = "";
    if($statusId>0) {
        $sql_status = " AND g.pagoStatusId = $statusId";
    }

    $sql_factura = "";
    if($factura=="si") {
        $sql_factura = " AND g.facturaUuid <> ''";
    } elseif($factura=="no") {
        $sql_factura = " AND g.facturaUuid = ''";
    }

    $sql_date = "";
    if(strtotime($dateFrom)!==false && strtotime($dateTo)!==false) {
        $sql_date = " AND ( g.fechaDePago BETWEEN '$dateFrom' AND '$dateTo' OR g.fechaDePago IS NULL )";
    }

    return sql_select(" SELECT 	g.gastoId, g.fechaDePago, g.concepto, g.moneda, g.total, 
                                p.titulo, 
                                v.razonSocial, v.banco, v.clabe, 
                                s.pagoStatusId, s.pagoStatus 
                        FROM 	".TABLE_POS." g, ".TABLE_PROJECTS." p, ".TABLE_VENDORS." v, ".TABLE_PAYMENTS_STATUS." s
                        WHERE 	g.proyectoId = p.proyectoId AND g.proveedorId = v.proveedorId AND 
                                g.pagoStatusId = s.pagoStatusId AND p.activo = 1 
                                $sql_project $sql_vendor $sql_status $sql_factura $sql_date
                        ORDER BY g.gastoId DESC
                        LIMIT 0, 300
                    ");

}

function get_pos_search_date_from($date) {
    if(strtotime($date)==false) {
        $date = date("Y-m-01", strtotime(date("Y-m-d")." -2 month"));
    }
    return $date;
}

function get_pos_search_date_to($date) {
    if(strtotime($date)==false) {
        $date = date("Y-m-t", strtotime(date("Y-m-d")." +2 month"));
    }
    return $date;
}

function get_po($poId) {
    return sql_select_row("SELECT p.*, ps.pagoStatus FROM ".TABLE_POS." p, ".TABLE_PAYMENTS_STATUS." ps WHERE p.pagoStatusId = ps.pagoStatusId AND p.gastoId = $poId");
}

function get_po_status($poId) {
    return (int)query_select_single_value("pagoStatusId", TABLE_POS, "gastoId = $poId");
}

function get_po_info($poId) {

    $po = get_po($poId);

    if($po['proyectoId']>0) {
        return sql_select_row("SELECT   g.gastoId, g.fechaDePago, g.concepto, g.moneda, g.tipoDeCambio, 
                                        g.monto, g.iva, g.retIVA, g.retISR, g.total, g.totalMXN, 
                                        g.pagoFormaId, g.pagoMetodoId, g.usoCfdiId, 
                                        g.facturaUuid, g.facturaInfo, g.referencia, g.notas, 
                                        p.proyectoId, p.uniqId, p.clave, p.titulo, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/facturas/') AS pathFacturas, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/transfers/') AS pathTransfers, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/comprobantes/') AS pathComprobantes, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/facturas/', g.facturaNombre, '.pdf') AS facturaPDF, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/facturas/', g.facturaNombre, '.xml') AS facturaXML, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/transfers/', g.transfer) AS transfer, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/transfers/', g.transfer2) AS transfer2, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/transfers/', g.transfer3) AS transfer3, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/comprobantes/', g.comprobante, '.pdf') AS comprobantePDF, 
                                        CONCAT('". PATH_PROJECTS . "', p.uniqId, '/comprobantes/', g.comprobante, '.xml') AS comprobanteXML, 
                                        v.*, 
                                        pf.claveFormaPago, CONCAT(pf.claveFormaPago, ' - ', pf.pagoForma) AS pagoForma, 
                                        pm.claveMetodoPago, CONCAT(pm.claveMetodoPago, ' - ', pm.pagoMetodo) AS pagoMetodo, 
                                        pu.claveUso, CONCAT(pu.claveUso, ' - ', pu.uso) AS usoCfdi, 
                                        ps.* 
                                FROM    ".TABLE_POS." g, ".TABLE_PROJECTS." p, ".TABLE_VENDORS." v, ".TABLE_SAT_FORMA_PAGO." pf, 
                                        ".TABLE_SAT_METODO_PAGO." pm, ".TABLE_SAT_USO_CFDI." pu, ".TABLE_PAYMENTS_STATUS." ps 
                                WHERE   g.proyectoId = p.proyectoId AND g.proveedorId = v.proveedorId AND 
                                        g.pagoFormaId = pf.pagoFormaId AND pm.pagoMetodoId = g.pagoMetodoId AND pu.usoCfdiId = g.usoCfdiId AND 
                                        g.pagoStatusId = ps.pagoStatusId AND 
                                        g.gastoId = $poId");
    } else {
        return sql_select_row("SELECT   g.gastoId, g.fechaDePago, g.concepto, g.moneda, g.tipoDeCambio, 
                                        g.monto, g.iva, g.retIVA, g.retISR, g.total, g.totalMXN, 
                                        g.pagoFormaId, g.pagoMetodoId, g.usoCfdiId, 
                                        g.facturaUuid, g.facturaInfo, g.referencia, g.notas, 
                                        g.proyectoId, 
                                        CONCAT('". PATH_EXPENSES . "') AS pathFacturas, 
                                        CONCAT('". PATH_EXPENSES . "') AS pathTransfers, 
                                        CONCAT('". PATH_EXPENSES . "') AS pathComprobantes, 
                                        CONCAT('". PATH_EXPENSES . "', g.facturaNombre, '.pdf') AS facturaPDF, 
                                        CONCAT('". PATH_EXPENSES . "', g.facturaNombre, '.xml') AS facturaXML, 
                                        CONCAT('". PATH_EXPENSES . "', g.transfer) AS transfer, 
                                        CONCAT('". PATH_EXPENSES . "', g.transfer2) AS transfer2, 
                                        CONCAT('". PATH_EXPENSES . "', g.transfer3) AS transfer3, 
                                        CONCAT('". PATH_EXPENSES . "', g.comprobante, '.pdf') AS comprobantePDF, 
                                        CONCAT('". PATH_EXPENSES . "', g.comprobante, '.xml') AS comprobanteXML, 
                                        v.*, 
                                        pf.claveFormaPago, CONCAT(pf.claveFormaPago, ' - ', pf.pagoForma) AS pagoForma, 
                                        pm.claveMetodoPago, CONCAT(pm.claveMetodoPago, ' - ', pm.pagoMetodo) AS pagoMetodo, 
                                        pu.claveUso, CONCAT(pu.claveUso, ' - ', pu.uso) AS usoCfdi, 
                                        ps.* 
                                FROM    ".TABLE_POS." g, ".TABLE_VENDORS." v, ".TABLE_PAYMENTS_STATUS." ps, 
                                        ".TABLE_SAT_FORMA_PAGO." pf, ".TABLE_SAT_METODO_PAGO." pm, ".TABLE_SAT_USO_CFDI." pu 
                                WHERE   g.proveedorId = v.proveedorId AND g.pagoStatusId = ps.pagoStatusId AND 
                                        g.pagoFormaId = pf.pagoFormaId AND pm.pagoMetodoId = g.pagoMetodoId AND pu.usoCfdiId = g.usoCfdiId AND 
                                        g.gastoId = $poId");
    }

}

function get_po_add_budgets() {
    return sql_select("SELECT p.proyectoId, b.presupuestoId, CONCAT(p.titulo, ' - ', LPAD(b.numero, 2, '0')) AS referencia 
                        FROM ".TABLE_PROJECTS." p, ".TABLE_PROJECTS_BUDGETS." b 
                        WHERE p.proyectoId = b.proyectoId AND p.activo = 1 AND p.deleted = 0 AND b.deleted = 0
                        ORDER BY referencia ASC");
}

function add_po_log($poId, $info, $debug=false) {
    $now = date("Y-m-d H:i:s");
    return query_insert(TABLE_POS_LOG, array("gastoId" => $poId, "fecha" => $now, "info" => $info), $debug);
}

function get_po_log($poId) {
    return sql_select("SELECT fecha, info FROM ".TABLE_POS_LOG." WHERE gastoId = $poId ORDER BY fecha ASC");
}

function get_payments_status() {
    return sql_select("SELECT * FROM ".TABLE_PAYMENTS_STATUS);
}

function get_payments_status_role($roleId, $pagoStatusId=0) {
    
    global $global_perms;
    
    $sql_status = "";
    if(!$global_perms['AUTHORIZE'] && $pagoStatusId!=PAYMENT_STATUS_AUTHORIZED) {
        $sql_status .= " AND pagoStatusId <> ".PAYMENT_STATUS_AUTHORIZED;
    }
    if(!$global_perms['PAY'] && $pagoStatusId!=PAYMENT_STATUS_PAYED) {
        $sql_status .= " AND pagoStatusId <> ".PAYMENT_STATUS_PAYED;
    }
    
    return sql_select("SELECT * FROM ".TABLE_PAYMENTS_STATUS." WHERE 1 $sql_status");
}

function get_expenses($vendor, $statusId, $factura, $dateFrom, $dateTo) {

    $sql_vendor = "";
    if($vendor!="") {
        $sql_vendor = " AND (v.rfc LIKE '%$vendor%' OR v.razonSocial LIKE '%$vendor%' OR v.email LIKE '%$vendor%')";
    }

    $sql_status = "";
    if($statusId>0) {
        $sql_status = " AND g.pagoStatusId = $statusId";
    }

    $sql_factura = "";
    if($factura=="si") {
        $sql_factura = " AND g.facturaUuid <> ''";
    } elseif($factura=="no") {
        $sql_factura = " AND g.facturaUuid = ''";
    }

    $sql_date = " AND ( g.fechaDePago BETWEEN '$dateFrom' AND '$dateTo' OR g.fechaDePago IS NULL )";

    return sql_select(" SELECT 	'-' AS titulo, g.concepto, 
                                v.razonSocial, v.banco, v.clabe, 
                                g.gastoId, g.fechaDePago, g.moneda, g.total, 
                                s.pagoStatus 
                        FROM 	".TABLE_POS." g, ".TABLE_VENDORS." v, ".TABLE_PAYMENTS_STATUS." s
                        WHERE 	g.proveedorId = v.proveedorId AND g.pagoStatusId = s.pagoStatusId AND g.proyectoId = 0 
                                $sql_vendor $sql_status $sql_factura $sql_date
                    ");

}

function get_expenses_path() {
    return PATH_EXPENSES;
}

function pos_get_payment_date() {

    $now = date("Y-m-d");
    $weeks = strtotime("$now +".PAYMENT_WEEKS." weeks");
    $weekday = (int)date("N", $weeks)."<br>";

    if((int)$weekday==(int)PAYMENT_DAY) {
        $payment_date = date("Y-m-d", $weeks);
    } elseif($weekday<PAYMENT_DAY) {
        $diff = (int)PAYMENT_DAY - (int)$weekday;
        $payment_date = date("Y-m-d", strtotime(date("Y-m-d", $weeks)." +$diff days"));
    } else {
        $weeks = strtotime(date("Y-m-d", $weeks)." +1 weeks");
        $diff = (int)$weekday - (int)PAYMENT_DAY;
        $payment_date = date("Y-m-d", strtotime(date("Y-m-d", $weeks)." -$diff days"));
    }

    return $payment_date;

}

/** Invoices functions **/

function get_invoice_xml_info($filename) {

    # validate xml
    libxml_use_internal_errors(TRUE);
    $dom = new DOMDocument();
    $dom->load($filename);
    $errors = libxml_get_errors();

    if(empty($errors) || (is_array($errors) && count($errors)==1 && $errors[0]->code==99) ) {
        # read xml
        $cfdi = new CFDI($filename);
        $values = $cfdi->get_cfdi_info();
        return $values;
    }

    $new_file_name = file_filter_filename($new_file_name);

    return false;

}

function get_invoice_filename($invoice_info) {

    return $invoice_info['UUID'];

}

function get_comprobante_filename($filename) {

    return pathinfo($filename, PATHINFO_FILENAME);

}

function invoice_exists($uuid) {

    $invoice = sql_select_row("SELECT gastoId FROM ".TABLE_POS." WHERE facturaUuid = '$uuid'");
    if($invoice==false) {
        return false;
    }

    return true;

}

function invoice_upload($filename, $path_invoices, $new_file_name) {
    return file_upload($filename, $path_invoices, $new_file_name);
}

function document_upload($filename, $path, $new_file_name) {

    $upload = file_upload($filename, $path, $new_file_name);

    if($upload!==true) {
        set_alert("warning", $upload);
    }

    return $upload;

}

function cfdi_get_info($invoice_xml) {

    # vars
    $error = false;

    # validate xml
    libxml_use_internal_errors(TRUE);
    $dom = new DOMDocument();
    $dom->load($invoice_xml['tmp_name']);
    $errors = libxml_get_errors();

    if(empty($errors) || (is_array($errors) && count($errors)==1 && $errors[0]->code==99) ) {
        $cfdi = new CFDI($invoice_xml['tmp_name']);
        $invoice_info = $cfdi->get_cfdi_info();
    } else {
        $error = true;
        set_alert("error", "Hubo un error al procesar el CFDI (archivo xml) o el archivo es inválido.");
        if(session_get_data("userId")==1) {
            var_dump($errors);
            die();
        }
    }

    if($error==false && $invoice_info===false) {
        $error = true;
        set_alert("error", "Hubo un error al procesar el CFDI (archivo xml) o el archivo es inválido.");
    }

    if($error==false) {
        return $invoice_info;
    } else {
        return false;
    }

}

function cfdi_valida_full($posInfo, $invoice_info) {

    # vars
    $error = false;
    $company_info = get_company_info();

    # invoice exists
    $invoice_exists = invoice_exists($invoice_info['UUID']);
    if($error==false && $invoice_exists==true) {
        $error = true;
        set_alert("error", "Esta factura ya fue subida anteriormente.");
    }

    # rfc receptor
    $invoice_rfc = trim(mb_strtoupper(str_replace(array(",", "."), "", $invoice_info['Receptor RFC'])));
    $pos_rfc = trim(mb_strtoupper(str_replace(array(",", "."), "", $company_info['rfc'])));
    if($error==false && $invoice_rfc!=$pos_rfc) {
        $error = true;
        set_alert("error", "El RFC del receptor no coincide.");
    }

    # rfc emisor
    $invoice_rfc = trim(mb_strtoupper(str_replace(array(",", "."), "", $invoice_info['Emisor RFC'])));
    $pos_rfc = trim(mb_strtoupper(str_replace(array(",", "."), "", $posInfo['rfc'])));
    if($error==false && $invoice_rfc!=$pos_rfc) {
        $error = true;
        set_alert("error", "El RFC del emisor no coincide.");
    }

    # uso cfdi
    if($error==false && $invoice_info['UsoCFDI']!=$posInfo['claveUso']) {
        $error = true;
        set_alert("error", "El uso del CFDI debe ser ".$posInfo['claveUso'].".");
    }

    # forma de pago
    if($error==false && $invoice_info['FormaPago']!=$posInfo['claveFormaPago']) {
        $error = true;
        set_alert("error", "La forma de pago del CFDI debe ser ".$posInfo['claveFormaPago'].".");
    }

    # metodo de pago
    if($error==false && $invoice_info['MetodoPago']!=$posInfo['claveMetodoPago']) {
        $error = true;
        set_alert("error", "El método de pago del CFDI debe ser ".$posInfo['claveMetodoPago'].".");
    }

    # subtotal, taxes & total
    if($error==false) {
        $subtotal_min = ($posInfo['monto'] - (int)PAYMENT_AMOUNT_RANGE);
        $subtotal_max = ($posInfo['monto'] + (int)PAYMENT_AMOUNT_RANGE);
        $traslados_min = ($posInfo['iva'] - (int)PAYMENT_AMOUNT_RANGE);
        $traslados_max = ($posInfo['iva'] + (int)PAYMENT_AMOUNT_RANGE);
        $retenciones_min = (($posInfo['retIVA']+$posInfo['retISR']) - (int)PAYMENT_AMOUNT_RANGE);
        $retenciones_max = (($posInfo['retIVA']+$posInfo['retISR']) + (int)PAYMENT_AMOUNT_RANGE);
        $total_min = ($posInfo['total'] - (int)PAYMENT_AMOUNT_RANGE);
        $total_max = ($posInfo['total'] + (int)PAYMENT_AMOUNT_RANGE);
        if( $invoice_info['Subtotal']<$subtotal_min || $invoice_info['Subtotal']>$subtotal_max || 
            $invoice_info['Traslados']<$traslados_min || $invoice_info['Traslados']>$traslados_max || 
            $invoice_info['Retenciones']<$retenciones_min || $invoice_info['Retenciones']>$retenciones_max || 
            $invoice_info['Total']<$total_min || $invoice_info['Total']>$total_max 
        ) {
            $error = true;
            set_alert("error", "Los importes (Subtotal, Impuestos y/o Total) del CFDI no son correctos.");
        }
    }
    
    # validacion ante el sat
    if((bool)VALIDA_CFDI_SAT==true) {
        if($error==false && cfdi_valida_sat($invoice_info['UUID'], $invoice_info['Emisor RFC'], $invoice_info['Receptor RFC'], $invoice_info['Total'])==false) {
            $error = true;
            set_alert("error", "El CFDI no fue encontrado en el SAT o no se encuentra Vigente.");
        }
    }

    return $error;

}

function cfdi_valida_sat($uuid, $emisor, $receptor, $total) {

    # formar cadena
    $soap = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/"><soapenv:Header/><soapenv:Body><tem:Consulta><tem:expresionImpresa>?re='.$emisor.'&amp;rr='.$receptor.'&amp;tt='.$total.'&amp;id='.$uuid.'</tem:expresionImpresa></tem:Consulta></soapenv:Body></soapenv:Envelope>';

    # encabezados
    $headers = array(
        'Content-Type: text/xml;charset=utf-8',
        'SOAPAction: http://tempuri.org/IConsultaCFDIService/Consulta',
        'Content-length: '.strlen($soap)
    );

    # consulta
    $url = 'https://consultaqr.facturaelectronica.sat.gob.mx/ConsultaCFDIService.svc';

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $soap);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $res = curl_exec($ch);

    curl_close($ch);

    # parse result
    $xml = simplexml_load_string($res);
    $data = $xml->children('s', true)->children('', true)->children('', true);
    $data = json_encode($data->children('a', true), JSON_UNESCAPED_UNICODE);
    $data = json_decode($data, true);

    # verify result
    if(isset($data['CodigoEstatus']) && $data['CodigoEstatus']=="S - Comprobante obtenido satisfactoriamente.") {
        if(isset($data['Estado']) && $data['Estado']=="Vigente") {
            return true;
        }
    }

    return false;

}



/** Accounts functions **/

function get_accounts_exist() {

    $results = sql_select_row("SELECT COUNT(*) AS total FROM ".TABLE_CUSTOMERS." WHERE deleted = 0");
    return ((int)$results['total']==0) ? false : true;

}

/** SAT tables functions **/

function get_sat_forma_pago() {
    return sql_select("SELECT *, CONCAT(claveFormaPago, ' - ', pagoForma) AS pagoFormaFull FROM ".TABLE_SAT_FORMA_PAGO);
}

function get_sat_metodo_pago() {
    return sql_select("SELECT *, CONCAT(claveMetodoPago, ' - ', pagoMetodo) AS pagoMetodoFull FROM ".TABLE_SAT_METODO_PAGO);
}

function get_sat_uso_cfdi() {
    return sql_select("SELECT *, CONCAT(claveUso, ' - ', uso) AS usoFull FROM ".TABLE_SAT_USO_CFDI);
}


/** User functions **/

// get user info


/** Reports **/


/** Settings */

function load_settings() {
    $settings	= sql_select("SELECT configKey, configValue FROM ".TABLE_SETTINGS);
    if($settings) {
        foreach($settings as $config) {
            $key = $config['configKey'];
            define("$key", $config['configValue']);
        }
    }
}

function get_settings() {

    # vars
    global $global_perms;
    $settings = array();

    # query
    $sql_type = (!$global_perms['FULL']) ? 'WHERE configPublic = 1' : '';
    $results = sql_select("SELECT * FROM ".TABLE_SETTINGS." $sql_type ORDER BY configCat ASC, configName ASC");
    
    # process
    if($results) {
        foreach($results as $config) {
            if(class_exists($config['configType'])) {
                $options = ($config['configOptions']!="") ? json_decode($config['configOptions'], true) : '';
                $settings[] = new $config['configType']($config['configId'], $config['configCat'], $config['configKey'], $config['configName'], "span6 m-wrap", $config['configValue'], $options);
            }
        }
    }

    return $settings;

}

function get_settings_cats() {
    return sql_select("SELECT DISTINCT configCat FROM ".TABLE_SETTINGS." ORDER BY configCat ASC");
}

function get_setting($id) {
    return sql_select_row("SELECT * FROM ".TABLE_SETTINGS." WHERE configId = $id");
}


/** Nominas functions */

function get_nomina_info($nomina_id) {
    return sql_select_row("SELECT * FROM ".TABLE_WAGES." WHERE nominaId = $nomina_id");
}

function get_nominas($proyectoId, $dateFrom, $dateTo) {

    $sql_proy = ((int)$proyectoId>0) ? " AND p.proyectoId = $proyectoId" : "";
    $sql_date = " AND n.fecha BETWEEN '$dateFrom' AND '$dateTo'";

    return sql_select("SELECT n.*, p.titulo FROM ".TABLE_WAGES." n, ".TABLE_PROJECTS." p WHERE n.proyectoId = p.proyectoId $sql_proy $sql_date");

}

function wages_add($proyectoId, $archivo, $monto) {

    $values['proyectoId'] = $proyectoId;
    $values['fecha'] = date("Y-m-d");
    $values['archivo'] = $archivo;
    $values['monto'] = $monto;

    $id = query_insert(TABLE_WAGES, $values);

    system_log($id, TABLE_WAGES, "Add", json_encode($values));

    return $id;

}


/** Contracts functions */

function get_contracts($type="") {
    $sql_type = ($type=="") ? "" : " WHERE tipo = '$type'";
    return sql_select("SELECT * FROM ".TABLE_CONTRACTS.$sql_type);
}

function get_contracts_vendors($projectId, $vendor, $statusId, $dateFrom, $dateTo) {

    $sql_project = "";
    if($projectId>0) {
        $sql_project = " AND p.proyectoId = $projectId";
    }

    $sql_vendor = "";
    if($vendor!="") {
        $sql_vendor = " AND (v.rfc LIKE '%$vendor%' OR v.razonSocial LIKE '%$vendor%' OR v.email LIKE '%$vendor%')";
    }

    $sql_status = "";
    if($statusId>0) {
        $sql_status = " AND cp.firmaStatusId = $statusId";
    }

    $sql_date = " AND ( cp.firmaFecha BETWEEN '$dateFrom' AND '$dateTo' OR cp.firmaFecha IS NULL )";

    return sql_select(" SELECT p.proyectoId, p.titulo, v.razonSocial, 
                            CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/', contrato) AS contrato, 
                            CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/', anexo) AS anexo, 
                            CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/', carta) AS carta, 
                            cp.id, cp.firmaStatusId, cp.firmaFecha, 
                            cs.contratoStatus
                        FROM ".TABLE_PROJECTS." p, ".TABLE_CONTRACTS_VENDORS." cp, ".TABLE_VENDORS." v, ".TABLE_CONTRACTS_STATUS." cs 
                        WHERE p.proyectoId = cp.proyectoId AND cp.proveedorId = v.proveedorId AND cp.firmaStatusId = cs.contratoStatusId
                            $sql_project
                            $sql_vendor
                            $sql_status
                            $sql_date
                        ");

}

function get_contract($id) {
    return sql_select_row("SELECT * FROM ".TABLE_CONTRACTS." WHERE contratoId = $id");
}

function get_contract_by_type($class_name) {
    return sql_select_row("SELECT * FROM ".TABLE_CONTRACTS." WHERE className = '$class_name'");
}

function get_contract_vendor($id) {
    return sql_select_row("SELECT * FROM ".TABLE_CONTRACTS_VENDORS." WHERE id = $id");
}

function get_contract_type_for_vendor($vendorId, $type) {

    $vendor = get_vendor($vendorId);
    $agencia = ($vendor['agencia']==1) ? 'Agencias' : '';
    $vendor_type = strtoupper(get_vendor_type($vendor['rfc']));

    if($type=="co") {
        return "Contract" . $agencia . $vendor_type;
    } else {
        return "Contract" . $agencia . "NDA";
    }

}

function vendor_has_contract_for_project($vendorId, $proyectoId) {
    return sql_select_row("SELECT id FROM ".TABLE_CONTRACTS_VENDORS." WHERE proveedorId = $vendorId AND proyectoId = $proyectoId");
}

function vendor_add_contract($vendorId, $proyectoId) {
    return query_insert(TABLE_CONTRACTS_VENDORS, array("proveedorId" => $vendorId, "proyectoId" => $proyectoId, "info" => ""));
}

function vendor_remove_contract($vendorId, $proyectoId) {
    $record = sql_select_row("SELECT * FROM ".TABLE_CONTRACTS_VENDORS." WHERE proveedorId = $vendorId AND proyectoId = $proyectoId");
    file_delete($record['contrato']);
    file_delete($record['anexo']);
    file_delete($record['carta']);
    return query_delete(TABLE_CONTRACTS_VENDORS, "proveedorId = $vendorId AND proyectoId = $proyectoId");
}

function get_contract_raw($contract_id) {

    $record = get_contract($contract_id);

    if($record) {
        return base64_decode($record['contrato']);
    }

    return false;

}

function get_contract_body($contract) {

    $firma_start = strpos($contract, "--FIRMA--");

    if($firma_start!==false) {
        $contract = substr($contract, 0, $firma_start);
    }

    return $contract;

}

function get_contract_html($contract) {

    // replace [] with <b> tags
    $contract = str_replace( array("[", "]"), array("<b>", "</b>"), $contract);

    // replace newlines
    $contract = nl2br($contract);

    return $contract;
    
}

function get_contract_html_for_pdf($contract) {

    // replace [] with <b> tags
    $contract = str_replace( array("[", "]"), array("<b>", "</b>"), utf8_decode($contract));

    return $contract;
    
}

function get_contract_fields($contract) {

    preg_match_all('/\{(.*?)\}/s', $contract, $matches);
    
    if(is_array($matches) && isset($matches[0])) {

        $search = array_unique($matches[0]);
        $names = array_unique($matches[1]);

    }

    $fields = array();
    if(isset($names) && count($names)>0) {
        for($i=0; $i<count($names); $i++) {
            $req = (substr($names[$i], -1)=="*") ? true : false;
            $field = ($req) ? substr($names[$i], 0, strlen($names[$i])-1) : $names[$i];
            $fields[] = array("search" => $search[$i], "field" => $field, "text" => str_replace(array("_", "*"), " ", $names[$i]), "req" => $req, "res" => "");
            
        }
    }

    return $fields;

}

function replace_contract_info($contract, $project, $vendor) {

    // replace project
    $search_project = array( "PROYECTO_CLAVE", "PROYECTO_NOMBRE", "PROYECTO_CLIENTE", "PROYECTO_FECHA_FILMACION", "PROYECTO_DIRECTOR", "PROYECTO_PRODUCTOR" );
    $replace_project = array( $project['clave'], $project['titulo'], $project['cliente'], $project['diaFilmacion'], $project['director'], $project['productor'] );

    // replace vendor info
    $search_vendor = array( "PROVEEDOR_RFC", "PROVEEDOR_RAZON_SOCIAL", "PROVEEDOR_EMAIL", "PROVEEDOR_BANCO", "PROVEEDOR_CUENTA", "PROVEEDOR_CLABE" );
    $replace_vendor = array( $vendor['rfc'], $vendor['razonSocial'], $vendor['email'], $vendor['banco'], $vendor['cuenta'], $vendor['clabe'] );

    // replace date & other info
    $search_date = array( "FECHA_DIAS", "FECHA_MES", "FECHA_AÑO", "--FIRMA--" );
    $replace_date = array( date("d"), get_date_es("F", date("Y-m-d")), date("Y"), "" );

    $contract = str_replace( $search_project, $replace_project, $contract );
    $contract = str_replace( $search_vendor, $replace_vendor, $contract );
    $contract = str_replace( $search_date, $replace_date, $contract );

    return $contract;

}

function replace_contract_fields($contract, $fields) {

    if(var_is_valid_array($fields)) {
        foreach($fields as $key => $value) {
            $contract = str_replace($key, $value, $contract);
        }
    }

    return $contract;

}

function get_contracts_status() {
    return sql_select("SELECT * FROM ".TABLE_CONTRACTS_STATUS);
}

function get_contract_filename($rfc, $type) {
    return $rfc."_".uniqid()."_".$type.".pdf";
}

function get_contract_signature_filename($rfc) {
    return $rfc."_".uniqid().".png";
}

function get_contract_attach_filename($rfc) {
    return $rfc."_".uniqid()."_anexo.pdf";
}

function save_contract_signature($path, $filename, $image) {

    if(!file_exists($path)) {
        mkdir($path);
    }

    return file_put_contents($path.$filename, $image);

}

function save_contract_attach($document, $path, $filename) {

    if(!file_exists($path)) {
        mkdir($path);
    }

    return file_upload($document['tmp_name'], $path, $filename);

}

function get_contract_status($id) {
    return query_select_single_value("firmaStatusId", TABLE_CONTRACTS_VENDORS, "id = $id");
}

function get_contracts_vendor($vendorId) {

    return sql_select(" SELECT p.proyectoId, p.titulo, cp.*, cs.contratoStatus, 
                                CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/', contrato) AS contrato, 
                                CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/', anexo) AS anexo, 
                                CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/', carta) AS carta, 
                                CONCAT('".PATH_PROJECTS."', p.uniqId, '/firmas/') AS pathFirmas, 
                                CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/') AS pathContratos 
                        FROM ".TABLE_PROJECTS." p, ".TABLE_CONTRACTS_VENDORS." cp, ".TABLE_CONTRACTS_STATUS." cs
                        WHERE p.proyectoId = cp.proyectoId AND cp.firmaStatusId = cs.contratoStatusId AND
                                cp.proveedorId = $vendorId");
    
}

function get_vendor_contract_info($id) {

    return sql_select_row(" SELECT p.proyectoId, p.titulo, cp.*, cs.contratoStatus, 
                                    CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/', contrato) AS contrato, 
                                    CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/', carta) AS carta, 
                                    CONCAT('".PATH_PROJECTS."', p.uniqId, '/firmas/') AS pathFirmas, 
                                    CONCAT('".PATH_PROJECTS."', p.uniqId, '/contratos/') AS pathContratos 
                            FROM ".TABLE_PROJECTS." p, ".TABLE_CONTRACTS_VENDORS." cp, ".TABLE_CONTRACTS_STATUS." cs 
                            WHERE p.proyectoId = cp.proyectoId AND cp.firmaStatusId = cs.contratoStatusId AND cp.id = $id",true);

}


?>